// AI Mail Genie / background.js (MV3 Service Worker)
//
// Responsibilities:
// - Calls FastAPI on Render (holds OpenAI key) for /ai/chat
// - Enforces a simple per-install daily rate-limit
// - Caches only the initial briefing per thread
// - Stores licenseKey + deviceId locally and auto-attaches them to /ai/chat payloads
// - Persists inferred plan (free/pro) so content.js can update UI reliably
//
// NOTE: manifest.json host_permissions must include `${API_BASE}/*`

const API_BASE = "https://api.aiemailgenie.com";

const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
const MAX_CALLS_PER_DAY_PER_INSTALL = 40;
const FETCH_TIMEOUT_MS = 20000;

const STORAGE = {
  CACHE: "aiCache",
  // plan visible to content.js
  PLAN: "amgPlan",
  // license + device identity
  LICENSE_KEY: "amgLicenseKey",
  DEVICE_ID: "amgDeviceId"
};

async function getStore(keys) {
  return await chrome.storage.local.get(keys);
}
async function setStore(obj) {
  return await chrome.storage.local.set(obj);
}

function todayKeyLocal() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function makeBriefingCacheKey(payload) {
  // Keep this stable and small; do not include message body.
  const safe = {
    provider: payload.provider || "gmail",
    threadKey: payload.threadKey || "",
    senderEmail: payload.senderEmail || "",
    senderDomain: payload.senderDomain || "",
    subjectHint: (payload.subject || "").slice(0, 80),
    linkDomains: (payload.linkDomains || []).slice(0, 12),
    mailedBy: payload.mailedBy || "",
    signedBy: payload.signedBy || "",
    paymentChanged: !!payload.paymentChanged
  };
  return "brief:" + btoa(unescape(encodeURIComponent(JSON.stringify(safe)))).slice(0, 200);
}

async function checkRateLimit() {
  const k = "aiCalls:" + todayKeyLocal();
  const st = await getStore([k]);
  const used = Number(st[k] || 0);

  if (used >= MAX_CALLS_PER_DAY_PER_INSTALL) {
    return { ok: false, used, limit: MAX_CALLS_PER_DAY_PER_INSTALL };
  }
  await setStore({ [k]: used + 1 });
  return { ok: true, used: used + 1, limit: MAX_CALLS_PER_DAY_PER_INSTALL };
}

async function postJSON(path, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);

  try {
    const res = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`AI API error ${res.status}: ${txt || "unknown error"}`);
    }
    return await res.json();
  } catch (e) {
    if (e && e.name === "AbortError") {
      throw new Error(
        `AI API request timed out. Check server health: ${API_BASE}/health`
      );
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

function inferPlanFromReply(replyText) {
  const t = (replyText || "").toLowerCase();
  if (!t) return null;

  // If server refused follow-up, that's free
  if (
    t.includes("follow-up questions are available in ai mail genie pro") ||
    t.includes("this is a pro-only feature") ||
    t.includes("upgrade to ai mail genie pro") ||
    t.includes("upgrade to pro to continue")
  ) {
    return "free";
  }

  // If Pro-only sections exist, treat as pro
  if (
    t.includes("risk drivers (ranked)") ||
    t.includes("what would make this safe?") ||
    t.includes("action templates")
  ) {
    return "pro";
  }

  return null;
}

function normalizePlan(p) {
  const plan = p && typeof p === "object" ? p : {};
  const mode = String(plan.mode || "free").toLowerCase() === "pro" ? "pro" : "free";
  const strict = String(plan.strictness || "normal").toLowerCase();
  const strictness =
    strict === "strict_finance" ? "strict_finance" : strict === "low_noise" ? "low_noise" : "normal";

  const tierRaw = String(plan.tier || (mode === "pro" ? "lifetime" : "free")).toLowerCase();
  const tier =
    tierRaw === "monthly" || tierRaw === "yearly" || tierRaw === "lifetime" ? tierRaw : (mode === "pro" ? "lifetime" : "free");

  const expiresAt = plan.expiresAt ? String(plan.expiresAt) : null;

  return { mode, tier, expiresAt, strictness };
}

async function persistPlanObject(plan) {
  const p = normalizePlan(plan);
  await setStore({ [STORAGE.PLAN]: p });
}

async function persistPlan(mode, strictness) {
  // Backward-compatible helper
  await persistPlanObject({ mode, strictness });
}

async function activateLicenseOnServer(licenseKey, deviceId) {
  // Your backend must implement this endpoint (Render -> Cloudflare D1)
  // Expected response:
  // { ok: true, plan: { mode:"pro", tier:"monthly|yearly|lifetime", expiresAt: "ISO" | null, strictness:"normal" } }
  // or { ok:false, error:"invalid_key|expired|revoked|device_limit_reached|..." }
  return await postJSON("/license/activate", { licenseKey, deviceId });
}


async function ensureDeviceId() {
  const st = await getStore([STORAGE.DEVICE_ID]);
  let deviceId = (st[STORAGE.DEVICE_ID] || "").trim();
  if (deviceId) return deviceId;

  // crypto.randomUUID exists in MV3 SW
  deviceId = (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`).slice(0, 120);
  await setStore({ [STORAGE.DEVICE_ID]: deviceId });
  return deviceId;
}

async function getLicenseAndDevice() {
  const st = await getStore([STORAGE.LICENSE_KEY, STORAGE.DEVICE_ID]);
  const licenseKey = (st[STORAGE.LICENSE_KEY] || "").trim();
  const deviceId = (st[STORAGE.DEVICE_ID] || "").trim() || (await ensureDeviceId());
  return { licenseKey, deviceId };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (!msg || !msg.type) return;

      // -----------------------------
      // Save product key (license) from content.js
      // -----------------------------
      if (msg.type === "AMG_SAVE_LICENSE") {
        const licenseKey = String(msg.licenseKey || "").trim();
        if (!licenseKey) {
          sendResponse({ ok: false, error: "licenseKey_required" });
          return;
        }

        const deviceId = await ensureDeviceId();

        // Server-authoritative activation (DO NOT trust client input).
        let result;
        try {
          result = await activateLicenseOnServer(licenseKey, deviceId);
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e || "activation_failed") });
          return;
        }

        if (!result || result.ok !== true || !result.plan) {
          // Do not store invalid keys.
          await setStore({ [STORAGE.LICENSE_KEY]: "" });
          await persistPlanObject({ mode: "free", strictness: "normal", tier: "free", expiresAt: null });
          sendResponse({ ok: false, error: result?.error || "invalid_license" });
          return;
        }

        const plan = normalizePlan(result.plan);

        await setStore({ [STORAGE.LICENSE_KEY]: licenseKey });
        await persistPlanObject(plan);

        sendResponse({ ok: true, licenseKey, deviceId, plan });
        return;
      }

      // Clear license + revert to free
      if (msg.type === "AMG_CLEAR_LICENSE") {
        await setStore({ [STORAGE.LICENSE_KEY]: "" });
        await persistPlan("free", "normal");
        const deviceId = await ensureDeviceId();
        sendResponse({ ok: true, deviceId });
        return;
      }

      // Get current plan + identity
      if (msg.type === "AMG_GET_STATUS") {
        const st = await getStore([STORAGE.PLAN]);
        const plan = normalizePlan(st[STORAGE.PLAN] || { mode: "free", tier: "free", expiresAt: null, strictness: "normal" });
        const { licenseKey, deviceId } = await getLicenseAndDevice();
        sendResponse({ ok: true, plan, licenseKey, deviceId, apiBase: API_BASE });
        return;
      }

      // -----------------------------
      // Main AI chat path
      // -----------------------------
      if (msg.type !== "AI_CHAT") return;

      const payload = msg.payload || {};
      const isBriefing = !payload.userMessage;

      // Attach licenseKey/deviceId automatically if not supplied
      const id = await getLicenseAndDevice();
      if (!payload.licenseKey && id.licenseKey) payload.licenseKey = id.licenseKey;
      if (!payload.deviceId && id.deviceId) payload.deviceId = id.deviceId;

      // Cache only the initial briefing.
      if (isBriefing) {
        const cacheKey = makeBriefingCacheKey(payload);
        const st = await getStore([STORAGE.CACHE]);
        const aiCache = st[STORAGE.CACHE] || {};
        const cached = aiCache[cacheKey];

        if (cached && cached.ts && Date.now() - cached.ts < CACHE_TTL_MS) {
          // Even on cached, still ensure plan is consistent
          const reply = cached?.data?.reply || cached?.data?.summary || "";
          const inferred = inferPlanFromReply(reply);
          if (inferred) await persistPlan(inferred, payload.strictness || "normal");

          sendResponse({ ok: true, cached: true, data: cached.data });
          return;
        }

        const rl = await checkRateLimit();
        if (!rl.ok) {
          sendResponse({
            ok: false,
            error: `Daily AI limit reached (${rl.limit}). Try again tomorrow.`,
            rateLimit: rl
          });
          return;
        }

        const data = await postJSON("/ai/chat", payload);

        // Prefer server-provided plan if available.
        if (data?.plan) {
          await persistPlanObject(data.plan);
        }

        // If server did not provide a plan, fall back to heuristic inference.
        if (!data?.plan) {
          if (!data?.plan) {
      const reply = data?.reply || data?.summary || "";
      const inferred = inferPlanFromReply(reply);
      if (inferred) await persistPlan(inferred, payload.strictness || "normal");
      }
        }

        aiCache[cacheKey] = { ts: Date.now(), data };
        await setStore({ [STORAGE.CACHE]: aiCache });

        sendResponse({ ok: true, cached: false, data });
        return;
      }

      // Follow-up messages are not cached.
      const rl = await checkRateLimit();
      if (!rl.ok) {
        sendResponse({
          ok: false,
          error: `Daily AI limit reached (${rl.limit}). Try again tomorrow.`,
          rateLimit: rl
        });
        return;
      }

      const data = await postJSON("/ai/chat", payload);

      // Prefer server-provided plan if available.
      if (data?.plan) {
        await persistPlanObject(data.plan);
      }

      const reply = data?.reply || data?.summary || "";
      const inferred = inferPlanFromReply(reply);
      if (inferred) await persistPlan(inferred, payload.strictness || "normal");

      sendResponse({ ok: true, cached: false, data });
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();

  return true;
});
