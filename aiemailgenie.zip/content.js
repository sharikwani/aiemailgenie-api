(() => {
  // AI Mail Genie — AI-first content script
  //
  // UI features restored:
  // - Inbox toolbar "live" glowing icon near pagination (Gmail + Outlook heuristics)
  // - Top-right acrylic banner with Assistant / Settings / Dismiss
  // - Right-side assistant panel
  //
  // Monetization / licensing:
  // - Product key saved locally (device-scoped)
  // - Background service worker auto-attaches {licenseKey, deviceId} to /ai/chat
  // - UI flips to Pro immediately after Apply; server remains authoritative and can downgrade

  const LOG = (...a) => console.log("[AI Mail Genie]", ...a);

  // -------------------------
  // IDs / Constants
  // -------------------------
  const BANNER_ID = "__amg_banner__";
  const PANEL_ID = "__amg_panel__";
  const STYLE_ID = "__amg_styles__";
  const TOP_BADGE_ID = "__amg_top_badge__";
  const SETTINGS_ID = "__amg_settings__";
  const COACH_ID = "__amg_coachmark__";

  const REQUEST_TIMEOUT_MS = 20000;

  // Plan (server-authoritative) + strictness
  let PLAN = { mode: "free", tier: "free", expiresAt: null, strictness: "normal" };
  let PLAN_MODE = "free"; // derived from PLAN.mode
  let PLAN_TIER = "free"; // "monthly" | "yearly" | "lifetime" | "free"
  let PLAN_EXPIRES_AT = null; // ISO string or null
  let STRICTNESS = "normal"; // derived from PLAN.strictness

  // License state (stored in background + chrome.storage.local)
  let LICENSE_KEY = "";
  let DEVICE_ID = "";

  const SETTINGS_KEY = "amgSettings";
  const POS_KEY = "amgBannerPos";
  const PLAN_KEY = "amgPlan";

  const DEFAULT_SETTINGS = {
    bannerOpacity: 0.88,
    panelOpacity: 0.92,
    enableBannerGlow: true,
    showToolbarLiveIcon: true,
    enableToolbarGlow: true,
    showAssistantCoachmark: true,
    analysisMode: "personal"
  };

const ALLOWLIST_KEY = "amgSenderAllowlist";
const BLOCKLIST_KEY = "amgSenderBlocklist";

let SENDER_ALLOWLIST = []; // normalized strings (emails/domains)
let SENDER_BLOCKLIST = []; // normalized strings (emails/domains)

function normSenderKey(v) {
  return String(v || "").trim().toLowerCase();
}

function senderMatches(list, senderEmail, senderDomain) {
  const e = normSenderKey(senderEmail);
  const d = normSenderKey(senderDomain);
  if (!list || !list.length) return false;
  if (e && list.includes(e)) return true;
  if (d && list.includes(d)) return true;
  const bd = normSenderKey(getBaseDomain(d));
  if (bd && list.includes(bd)) return true;
  return false;
}

async function loadSenderLists() {
  const out = await getStore([ALLOWLIST_KEY, BLOCKLIST_KEY]);
  SENDER_ALLOWLIST = Array.isArray(out[ALLOWLIST_KEY]) ? out[ALLOWLIST_KEY].map(normSenderKey).filter(Boolean) : [];
  SENDER_BLOCKLIST = Array.isArray(out[BLOCKLIST_KEY]) ? out[BLOCKLIST_KEY].map(normSenderKey).filter(Boolean) : [];
}

async function saveSenderLists() {
  await setStore({
    [ALLOWLIST_KEY]: SENDER_ALLOWLIST.slice(0, 200),
    [BLOCKLIST_KEY]: SENDER_BLOCKLIST.slice(0, 200)
  });
}

function isSenderWhitelisted(state) {
  return senderMatches(SENDER_ALLOWLIST, state?.senderEmail, state?.senderDomain);
}

function isSenderBlocked(state) {
  return senderMatches(SENDER_BLOCKLIST, state?.senderEmail, state?.senderDomain);
}


  // Render state
  let LAST_RENDERED_MESSAGES = [];

  function getAnalysisMode() {
    const m = (SETTINGS && SETTINGS.analysisMode) ? String(SETTINGS.analysisMode).toLowerCase() : "personal";
    return m === "business" ? "business" : "personal";
  }


  const DEFAULT_PLAN = {
    mode: "free",
    tier: "free",
    expiresAt: null,
    strictness: "normal"
  };

  const UPGRADE_URL = "https://aiemailgenie.com/";

  // -------------------------
  // Helpers
  // -------------------------
  const normalizeText = (s) => (s || "").replace(/\s+/g, " ").replace(/\u200B/g, "").trim();
  const extractPlainText = (el) => (el ? normalizeText(el.innerText || el.textContent || "") : "");

  const extractLinks = (el) => {
    if (!el) return [];
    const a = Array.from(el.querySelectorAll("a[href]"));
    const out = [];
    for (const x of a) {
      const href = x.getAttribute("href") || "";
      if (href.startsWith("http://") || href.startsWith("https://")) out.push(href);
    }
    return Array.from(new Set(out));
  };

  const getDomainFromUrl = (url) => {
    try {
      return new URL(url).hostname.toLowerCase();
    } catch {
      return "";
    }
  };

  // Base-domain helper (best-effort eTLD+1) to avoid false mismatch flags for
  // legitimate subdomains like email.mg.mercury.com vs mercury.com.
  const COMMON_2LD_SUFFIXES = new Set([
    "co.uk","org.uk","ac.uk","gov.uk",
    "com.au","net.au","org.au",
    "co.in","firm.in","net.in","org.in","gen.in","ind.in",
    "co.nz","org.nz","govt.nz",
    "com.br","com.mx","com.tr","com.sa"
  ]);

  const getBaseDomain = (host) => {
    const h = (host || "").toLowerCase().replace(/\.+$/g, "").trim();
    if (!h) return "";
    if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(h)) return h;
    const parts = h.split(".").filter(Boolean);
    if (parts.length <= 2) return h;

    const suffix2 = parts.slice(-2).join(".");
    const suffix3 = parts.slice(-3).join(".");
    if (COMMON_2LD_SUFFIXES.has(suffix2) && parts.length >= 3) return parts.slice(-3).join(".");
    if (COMMON_2LD_SUFFIXES.has(suffix3) && parts.length >= 4) return parts.slice(-4).join(".");
    return parts.slice(-2).join(".");
  };

  const filterExternalLinkUrls = (urls, senderDomain) => {
    const senderBase = getBaseDomain(senderDomain);
    return (urls || []).filter((u) => {
      const host = getDomainFromUrl(u);
      if (!host) return false;
      if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return true;
      if ((host || "").startsWith("xn--")) return true;
      const base = getBaseDomain(host);
      return senderBase && base ? base !== senderBase : true;
    });
  };

  const getDomainFromEmail = (email) => {
    const m = (email || "").match(/@([a-z0-9.-]+\.[a-z]{2,})/i);
    return m ? m[1].toLowerCase() : "";
  };

  function escapeHtml(s) {
    return String(s || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function redactForAI(text) {
    let s = text || "";
    s = s.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[EMAIL]");
    s = s.replace(/\b\d{5,}\b/g, "[NUMBER]");
    s = s.replace(/\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/g, "[IBAN]");
    s = s.replace(/https?:\/\/\S+/gi, "[URL]");
    s = normalizeText(s);
    if (s.length > 1200) s = s.slice(0, 1200) + "…";
    return s;
  }

  async function sha256Hex(input) {
    const enc = new TextEncoder().encode(input);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    const bytes = Array.from(new Uint8Array(buf));
    return bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  function openUpgrade() {
    try {
      window.open(UPGRADE_URL, "_blank", "noopener,noreferrer");
    } catch {
      alert("Upgrade page could not be opened. Please try again.");
    }
  }

  function looksLikeUpgradeRequiredReply(text) {
    const t = (text || "").toLowerCase();
    return (
      t.includes("follow-up questions are available in ai mail genie pro") ||
      t.includes("this is a pro-only feature") ||
      t.includes("upgrade to ai mail genie pro") ||
      t.includes("upgrade to pro to continue")
    );
  }

  // -------------------------
  // Storage
  // -------------------------
  async function getStore(keys) {
    return await chrome.storage.local.get(keys);
  }
  async function setStore(obj) {
    return await chrome.storage.local.set(obj);
  }

  async function loadSettings() {
    const { amgSettings } = await getStore([SETTINGS_KEY]);
    return { ...DEFAULT_SETTINGS, ...(amgSettings || {}) };
  }
  async function saveSettings(next) {
    await setStore({ [SETTINGS_KEY]: next });
  }

  function normalizePlan(plan) {
    const p = plan && typeof plan === "object" ? plan : {};
    const mode = String(p.mode || "free").toLowerCase() === "pro" ? "pro" : "free";
    const strict = String(p.strictness || "normal").toLowerCase();
    const strictness =
      strict === "strict_finance" ? "strict_finance" : strict === "low_noise" ? "low_noise" : "normal";

    const tierRaw = String(p.tier || (mode === "pro" ? "lifetime" : "free")).toLowerCase();
    const tier =
      tierRaw === "monthly" || tierRaw === "yearly" || tierRaw === "lifetime"
        ? tierRaw
        : (mode === "pro" ? "lifetime" : "free");

    const expiresAt = p.expiresAt ? String(p.expiresAt) : null;

    return { mode, tier, expiresAt, strictness };
  }

  function isPlanExpired(plan) {
    const p = normalizePlan(plan);
    if (!p.expiresAt) return false; // lifetime / non-expiring
    const ts = Date.parse(p.expiresAt);
    if (!Number.isFinite(ts)) return false; // if backend sends weird value, don't brick user; backend should enforce
    return Date.now() > ts;
  }

  function applyPlanToRuntime(plan) {
    const p = normalizePlan(plan);
    // Client-side expiry check as a safety net; backend remains authoritative.
    const expired = p.mode === "pro" && isPlanExpired(p);
    PLAN = expired ? normalizePlan({ mode: "free", tier: "free", expiresAt: null, strictness: p.strictness }) : p;

    PLAN_MODE = PLAN.mode;
    PLAN_TIER = PLAN.tier;
    PLAN_EXPIRES_AT = PLAN.expiresAt;
    STRICTNESS = PLAN.strictness;
  }

  async function loadPlan() {
    const { amgPlan } = await getStore([PLAN_KEY]);
    return normalizePlan({ ...DEFAULT_PLAN, ...(amgPlan || {}) });
  }

  async function savePlan(mode, strictness) {
    // Backward-compatible helper
    await savePlanFull({ mode, strictness });
  }

  async function savePlanFull(plan) {
    const p = normalizePlan({ ...DEFAULT_PLAN, ...(plan || {}) });
    await setStore({ [PLAN_KEY]: p });
  }

  async function loadBannerPos() {
    const { amgBannerPos } = await getStore([POS_KEY]);
    return amgBannerPos || null;
  }
  async function saveBannerPos(pos) {
    await setStore({ [POS_KEY]: pos });
  }

  async function loadChatHistory(key) {
    const { igChat = {} } = await getStore(["igChat"]);
    return Array.isArray(igChat[key]) ? igChat[key] : [];
  }
  async function saveChatHistory(key, history) {
    const { igChat = {} } = await getStore(["igChat"]);
    igChat[key] = history.slice(-12);
    await setStore({ igChat });
  }

  async function getThreadState() {
    const { threadState = {} } = await getStore(["threadState"]);
    return threadState;
  }
  async function setThreadState(threadState) {
    await setStore({ threadState });
  }

  // -------------------------
  // Background bridge
  // -------------------------
  function sendToBackground(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (resp) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message || "Extension messaging error" });
          return;
        }
        resolve(resp || { ok: false, error: "no_response" });
      });
    });
  }

  function sendAIChat(payload) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve({ ok: false, error: "AI request timed out." });
      }, REQUEST_TIMEOUT_MS);

      chrome.runtime.sendMessage({ type: "AI_CHAT", payload }, (resp) => {
        clearTimeout(timer);
        if (settled) return;
        settled = true;

        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message || "Extension messaging error" });
          return;
        }
        resolve(resp);
      });
    });
  }

  async function refreshStatusFromBackground() {
    const resp = await sendToBackground({ type: "AMG_GET_STATUS" });
    if (resp?.ok) {
      const plan = resp.plan || {};
      applyPlanToRuntime(plan);
      LICENSE_KEY = (resp.licenseKey || "").trim();
      DEVICE_ID = (resp.deviceId || "").trim();
    }
  }

  // -------------------------
  // Styles
  // -------------------------
  let SETTINGS = { ...DEFAULT_SETTINGS };

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;

    const s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = `
      :root{
        --amg-banner-opacity: ${DEFAULT_SETTINGS.bannerOpacity};
        --amg-panel-opacity: ${DEFAULT_SETTINGS.panelOpacity};
      }

      @keyframes amgPulseGlow {
        0%   { box-shadow: 0 10px 22px rgba(0,0,0,.18), 0 0 0 0 rgba(0,122,255,.35), 0 0 0 0 rgba(88,86,214,.18); transform: translateY(0) scale(1); }
        50%  { box-shadow: 0 12px 26px rgba(0,0,0,.20), 0 0 0 10px rgba(0,122,255,.10), 0 0 18px 2px rgba(0,122,255,.32); transform: translateY(-0.2px) scale(1.02); }
        100% { box-shadow: 0 10px 22px rgba(0,0,0,.18), 0 0 0 0 rgba(0,122,255,.35), 0 0 0 0 rgba(88,86,214,.18); transform: translateY(0) scale(1); }
      }

      @keyframes amgSoftGlow {
        0%   { box-shadow: 0 8px 18px rgba(0,0,0,.14), 0 0 0 0 rgba(0,122,255,.18); }
        50%  { box-shadow: 0 10px 22px rgba(0,0,0,.16), 0 0 14px 1px rgba(0,122,255,.22); }
        100% { box-shadow: 0 8px 18px rgba(0,0,0,.14), 0 0 0 0 rgba(0,122,255,.18); }
      }

      #${TOP_BADGE_ID}{
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 12px;
        margin: 0 10px 0 0;
        border: 1px solid rgba(0,0,0,.12);
        background: rgba(255,255,255,.96);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        vertical-align: middle;
        animation: amgPulseGlow 1.6s ease-in-out infinite;
      }
      #${TOP_BADGE_ID}[data-glow="0"]{ animation:none; box-shadow: 0 10px 22px rgba(0,0,0,.18); }
      #${TOP_BADGE_ID} img{ width:26px;height:26px;display:block;filter: drop-shadow(0 2px 6px rgba(0,122,255,.40)); }

      #${BANNER_ID}{
        position: fixed;
        z-index: 2147483646;
        top: 10px;
        right: 12px;
        width: 540px;
        max-width: min(540px, 96vw);
        border-radius: 18px;
        border: 1px solid rgba(0,0,0,.12);
        background: linear-gradient(135deg, rgba(0,122,255,.16), rgba(255,255,255,.86) 40%, rgba(255,45,85,.10));
        box-shadow: 0 18px 60px rgba(0,0,0,.20);
        backdrop-filter: blur(10px);
        font-family: "Segoe UI Variable","Segoe UI",system-ui;
        color: rgba(0,0,0,.90);
        user-select: none;
        opacity: var(--amg-banner-opacity);
        cursor: grab;
      }
      #${BANNER_ID}.dragging{ cursor: grabbing; }
      #${BANNER_ID} .ig-top{display:flex;align-items:center;gap:10px;padding:10px 12px;}
      #${BANNER_ID} .ig-icon{
        width:36px;height:36px;border-radius:12px;
        background: linear-gradient(135deg, rgba(0,122,255,.28), rgba(88,86,214,.18));
        border: 1px solid rgba(0,0,0,.10);
        display:flex;align-items:center;justify-content:center;overflow:hidden;
        animation: amgSoftGlow 2.6s ease-in-out infinite;
      }
      #${BANNER_ID} .ig-icon[data-glow="0"]{ animation:none; box-shadow: 0 8px 18px rgba(0,0,0,.14); }
      #${BANNER_ID} .ig-icon img{width:26px;height:26px;display:block;filter: drop-shadow(0 2px 6px rgba(0,122,255,.28));}
      #${BANNER_ID} .ig-title{font-weight:950;font-size:14px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width: 360px;}
      #${BANNER_ID} .ig-sub{font-size:12px;color: rgba(0,0,0,.66);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width: 420px;}
      #${BANNER_ID} .ig-actions{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;}
      #${BANNER_ID} .ig-btn{border: 1px solid rgba(0,0,0,.12);background: rgba(255,255,255,.80);border-radius: 12px;padding:7px 10px;font-size:12px;font-weight:900;cursor:pointer;transition: transform .06s ease;}
      #${BANNER_ID} .ig-btn:hover{transform: translateY(-1px);}
      #${BANNER_ID} .ig-btn:active{transform: translateY(0);}

      #${SETTINGS_ID}{
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        width: 360px;
        max-width: min(360px, 92vw);
        border-radius: 14px;
        border: 1px solid rgba(0,0,0,.12);
        background: rgba(255,255,255,.94);
        box-shadow: 0 18px 50px rgba(0,0,0,.18);
        backdrop-filter: blur(10px);
        padding: 12px;
        display: none;
        z-index: 2147483647;
        cursor: default;
      }
      #${SETTINGS_ID}.open{ display:block; }
      #${SETTINGS_ID} .row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:10px 0;}
      #${SETTINGS_ID} .label{font-size:12px;font-weight:900;color: rgba(15,23,42,.92);}
      #${SETTINGS_ID} .desc{font-size:11px;color: rgba(15,23,42,.62);margin-top:2px;}
      #${SETTINGS_ID} input[type="range"]{width: 160px;}
      #${SETTINGS_ID} .toggle{display:flex;align-items:center;gap:8px;}
      #${SETTINGS_ID} .actions{display:flex;gap:8px;justify-content:flex-end;margin-top:10px;}
      #${SETTINGS_ID} .sbtn{border:1px solid rgba(0,0,0,.12);background: rgba(255,255,255,.90);border-radius:10px;padding:7px 10px;font-size:12px;font-weight:900;cursor:pointer;}

      #${PANEL_ID}{
        position: fixed;
        top: 0;
        right: 0;
        height: 100vh;
        width: min(420px, 92vw);
        z-index: 2147483647;
        border-left: 1px solid rgba(0,0,0,.12);
        background: linear-gradient(180deg, rgba(10,132,255,.14), rgba(255,255,255,.78) 22%, rgba(255,255,255,.86));
        backdrop-filter: blur(10px);
        box-shadow: -20px 0 60px rgba(0,0,0,.16);
        font-family: "Segoe UI Variable","Segoe UI",system-ui;
        display: none;
        flex-direction: column;
        opacity: var(--amg-panel-opacity);
      }
      #${PANEL_ID}.open{display:flex;}
      #${PANEL_ID} .p-head{
        display:flex;align-items:center;gap:10px;flex-wrap:wrap;
        border-bottom:1px solid rgba(255,255,255,.22);
        background: linear-gradient(90deg, rgba(10,20,60,.92), rgba(20,40,110,.86), rgba(90,30,120,.78));
        padding: 14px 14px;
      position: sticky; top: 0; z-index: 20;
      }
      #${PANEL_ID} .p-right{margin-left:auto;display:flex;align-items:center;gap:10px;flex:0 0 auto;min-width:0;flex-wrap:wrap;justify-content:flex-end;}
      #${PANEL_ID} .p-title{font-weight:950;font-size:14px;color: rgba(255,255,255,.94);}
      #${PANEL_ID} .p-meta{font-size:12px;color: rgba(255,255,255,.82);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
      #${PANEL_ID} .p-close{background: rgba(255,255,255,.22);border: 1px solid rgba(255,255,255,.28);border-radius: 10px;padding:7px 10px;font-size:12px;font-weight:900;cursor:pointer;color: rgba(255,255,255,.95);}

      #${PANEL_ID} .p-modes{
        display:inline-flex;flex:0 0 auto;max-width:100%;
        gap:6px;
        padding:4px;
        border-radius: 12px;
        background: rgba(255,255,255,.92);
        border: 1px solid rgba(0,0,0,.10);
      }
      #${PANEL_ID} .p-modebtn{
        border: 1px solid rgba(0,0,0,.12);
        background: rgba(255,255,255,.85);
        color: rgba(20,20,25,.92);
        border-radius: 10px;
        padding:6px 10px;
        font-size:12px;
        font-weight:950;
        cursor:pointer;
      }
      #${PANEL_ID} .p-modebtn[data-active="1"]{
        background: rgba(0,0,0,.10);
        border-color: rgba(255,255,255,.36);
        color: rgba(0,0,0,.92);
      }
      #${PANEL_ID} .p-body{padding:14px;overflow:auto;flex:1;}

      @media (max-width: 420px){
        #${PANEL_ID} .p-modes{width:100%;justify-content:space-between;}
        #${PANEL_ID} .p-modebtn{flex:1 1 0;text-align:center;}
      }
      #${PANEL_ID} .msg{
        border:1px solid rgba(0,0,0,.10);
        background: rgba(255,255,255,.90);
        border-radius: 14px;
        padding:12px 12px;
        margin-bottom:10px;
        font-size:14px;
        line-height:1.55;
        color: rgba(15,23,42,.96);
        box-shadow: 0 10px 30px rgba(0,0,0,.10);
        white-space: pre-wrap;
      }
      #${PANEL_ID} .msg.user{
        background: linear-gradient(135deg, rgba(0,122,255,.22), rgba(88,86,214,.14));
        border: 1px solid rgba(0,122,255,.18);
      }

      #${PANEL_ID} .hint{font-size:11px;color: rgba(0,0,0,.62);padding:0 12px 10px 12px;}

      #${PANEL_ID} .p-foot{
        padding:10px;
        border-top:1px solid rgba(0,0,0,.10);
        background: rgba(255,255,255,.58);
        backdrop-filter: blur(12px);
      }

      #${PANEL_ID} .foot-row{
        display:flex;
        gap:8px;
        align-items:flex-end;
      }
      #${PANEL_ID} textarea{
        flex:1;
        min-height:38px;
        max-height:120px;
        resize:none;
        border:1px solid rgba(0,0,0,.12);
        border-radius:12px;
        padding:8px 10px;
        font-size:12px;
        background: rgba(255,255,255,.92);
        color: rgba(0,0,0,.88);
      }
      #${PANEL_ID} .send{
        border-radius:12px;
        padding:8px 10px;
        font-size:12px;
        font-weight:900;
        cursor:pointer;
        background: linear-gradient(135deg, rgba(0,122,255,.88), rgba(88,86,214,.86));
        border: 1px solid rgba(255,255,255,.18);
        color: rgba(255,255,255,.96);
      }
      #${PANEL_ID} .send[disabled]{opacity:.55;cursor:not-allowed;}

      /* Free CTA + License entry */
      #${PANEL_ID} .free-cta{
        display:none;
        flex-direction: column;
        gap:10px;
        width:100%;
        border-radius: 16px;
        border: 1px solid rgba(0,0,0,.12);
        background: rgba(255,255,255,.96);
        box-shadow: 0 12px 34px rgba(0,0,0,.10);
        padding: 14px 14px;
      }
      #${PANEL_ID} .free-cta.open{ display:flex; }

      #${PANEL_ID} .free-cta .t1{ font-size: 13px; font-weight: 950; color: rgba(15,23,42,.92); line-height: 1.25; }
      #${PANEL_ID} .free-cta .t2{ margin-top: 6px; font-size: 12px; color: rgba(15,23,42,.66); line-height: 1.35; }
      #${PANEL_ID} .free-cta .row2{ display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
      #${PANEL_ID} .free-cta input{
        flex: 1 1 220px;
        min-width: 140px;
        border:1px solid rgba(0,0,0,.12);
        border-radius: 12px;
        padding: 10px 12px;
        font-size: 12px;
        background: rgba(255,255,255,.98);
      }
      #${PANEL_ID} .free-cta .apply{
        border-radius: 12px;
        padding: 10px 12px;
        font-size: 12px;
        font-weight: 950;
        cursor: pointer;
        border: 1px solid rgba(0,0,0,.12);
        background: rgba(255,255,255,.90);
      }
      #${PANEL_ID} .free-cta .upgrade{
        margin-left:auto;
        border-radius: 14px;
        padding: 11px 14px;
        font-size: 12px;
        font-weight: 950;
        cursor: pointer;
        background: linear-gradient(135deg, rgba(255,45,85,.92), rgba(88,86,214,.92));
        border: 1px solid rgba(255,255,255,.20);
        color: rgba(255,255,255,.98);
        white-space: nowrap;
      }
      #${PANEL_ID} .free-cta .msg2{ font-size: 11px; color: rgba(15,23,42,.62); }
      #${PANEL_ID} .p-count{
        
        margin-right:10px;
        font-size:11px;
        font-weight:900;
        color: rgba(255,255,255,.92);
        background: rgba(0,0,0,.18);
        border: 1px solid rgba(255,255,255,.22);
        padding: 4px 8px;
        border-radius: 999px;
      }
      /* -------------------------
         Premium UI (cards / confidence / badges / collapsibles / skeleton)
         ------------------------- */
      .amg-card{
        background: rgba(255,255,255,.78);
        border: 1px solid rgba(255,255,255,.22);
        border-radius: 16px;
        box-shadow: 0 10px 24px rgba(0,0,0,.14);
        overflow: hidden;
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        margin: 10px 10px 12px;
      }

.amg-ai-card{
  border: 2px solid transparent;
  background:
    linear-gradient(rgba(255,255,255,.78), rgba(255,255,255,.78)) padding-box,
    linear-gradient(90deg, rgba(16,185,129,.95), rgba(74,222,128,.95), rgba(254,240,138,.95), rgba(250,204,21,.95), rgba(252,165,165,.95), rgba(220,38,38,.95)) border-box;
  background-size: 100% 100%, 300% 300%;
  animation: amg-ai-border-move 3.5s linear infinite;
}
@keyframes amg-ai-border-move{
  0%{ background-position: 0 0, 0% 50%; }
  100%{ background-position: 0 0, 100% 50%; }
}
      .amg-card.darkish{
        background: rgba(20,22,26,.58);
        border-color: rgba(255,255,255,.10);
      }
      .amg-card .amg-card-h{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding: 10px 12px;
        border-bottom: 1px solid rgba(255,255,255,.14);
      }
      .amg-card .amg-card-title{
        font-weight: 700;
        font-size: 13px;
        letter-spacing: .2px;
        line-height: 1.2;
        color: rgba(20,20,22,.92);
      }
      #${PANEL_ID} .amg-card .amg-card-title,
      #${PANEL_ID} .amg-card .amg-kv,
      #${PANEL_ID} .amg-card .amg-sec-btn,
      #${PANEL_ID} .amg-card .amg-sec-body{
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      }

      .amg-card .amg-card-actions{
        display:flex;
        gap:8px;
        align-items:center;
        flex-wrap:wrap;
        justify-content:flex-end;
      }
      .amg-mini-btn{
        border: 1px solid rgba(0,0,0,.10);
        background: rgba(255,255,255,.6);
        color: rgba(20,20,22,.88);
        padding: 6px 9px;
        border-radius: 10px;
        font-size: 12px;
        cursor:pointer;
      }
      .amg-mini-btn:hover{ filter: brightness(1.03); }
      .amg-mini-btn:active{ transform: translateY(0.5px); }

      .amg-mini-btn[data-active="1"]{ background: rgba(0,0,0,.08); border-color: rgba(0,0,0,.18); font-weight: 800; }

      .amg-badges{
        display:flex;
        gap:6px;
        flex-wrap:wrap;
        align-items:center;
      }
      .amg-badge{
        display:inline-flex;
        align-items:center;
        gap:6px;
        padding: 4px 8px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 650;
        letter-spacing: .15px;
        border: 1px solid rgba(0,0,0,.10);
        background: rgba(255,255,255,.58);
        color: rgba(20,20,22,.86);
      }
      .amg-badge.good{
        border-color: rgba(34,197,94,.35);
        background: rgba(34,197,94,.10);
        color: rgba(20,70,35,.92);
      }
      .amg-badge.warn{
        border-color: rgba(245,158,11,.40);
        background: rgba(245,158,11,.12);
        color: rgba(92,54,10,.95);
      }
      .amg-badge.neutral{
        border-color: rgba(59,130,246,.35);
        background: rgba(59,130,246,.10);
        color: rgba(16,44,92,.95);
      }


.amg-note, .amg-note-ok, .amg-note-warn{
  margin-top: 10px;
  padding: 10px 10px;
  border-radius: 12px;
  font-size: 12px;
  line-height: 1.35;
  border: 1px solid rgba(0,0,0,.08);
  background: rgba(255,255,255,.55);
  color: rgba(15,15,18,.88);
}
.amg-note-ok{
  border-color: rgba(34,197,94,.28);
  background: rgba(34,197,94,.08);
}
.amg-note-warn{
  border-color: rgba(239,68,68,.30);
  background: rgba(239,68,68,.08);
}

      .amg-card .amg-card-b{
        padding: 10px 12px 12px;
      }

      .amg-conf-wrap{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        margin-top: 8px;
      }
      .amg-conf-label{
        font-size: 12px;
        color: rgba(20,20,22,.76);
        white-space: nowrap;
      }
      .amg-conf-bar{
        flex:1;
        height: 10px;
        border-radius: 999px;
        border: 1px solid rgba(0,0,0,.10);
        background: rgba(0,0,0,.06);
        overflow:hidden;
      }
      .amg-conf-fill{
        height:100%;
        width: 0%;
        border-radius: 999px;
        background: linear-gradient(90deg, rgba(59,130,246,.70), rgba(34,197,94,.70));
        transition: width .28s ease;
      }

      .amg-sections{
        margin-top: 10px;
        display:flex;
        flex-direction:column;
        gap:8px;
      }

      .amg-sec{
        border: 1px solid rgba(0,0,0,.08);
        background: rgba(255,255,255,.45);
        border-radius: 14px;
        overflow:hidden;
      }
      .amg-sec-h{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding: 10px 10px;
        cursor:pointer;
        user-select:none;
      }
      .amg-sec-title{
        font-size: 12px;
        font-weight: 750;
        color: rgba(20,20,22,.86);
        letter-spacing: .15px;
      }
      .amg-sec-btn{
        border: 1px solid rgba(0,0,0,.10);
        background: rgba(255,255,255,.55);
        padding: 6px 8px;
        border-radius: 10px;
        font-size: 12px;
        cursor:pointer;
        white-space: nowrap;
      }
      .amg-sec-body{
        padding: 10px 10px 12px;
        border-top: 1px solid rgba(0,0,0,.06);
        font-size: 12px;
        line-height: 1.45;
        color: rgba(20,20,22,.88);
        white-space: pre-wrap;
        word-break: break-word;
      }
      .amg-sec[data-open="0"] .amg-sec-body{ display:none; }

      .amg-kv{
        display:grid;
        grid-template-columns: 120px 1fr;
        gap: 6px 10px;
        font-size: 12px;
        line-height: 1.35;
        color: rgba(20,20,22,.86);
      }
      .amg-kv .k{ color: rgba(20,20,22,.66); }
      .amg-kv .v{ color: rgba(20,20,22,.90); overflow:hidden; text-overflow: ellipsis; }

      .amg-skel{
        position: relative;
        overflow:hidden;
      }
      .amg-skel::after{
        content:"";
        position:absolute; inset:0;
        background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,.35) 50%, rgba(255,255,255,0) 100%);
        transform: translateX(-120%);
        animation: amgSkelMove 1.2s infinite;
      }
      @keyframes amgSkelMove{
        0%{ transform: translateX(-120%); }
        100%{ transform: translateX(120%); }
      }
      .amg-skel-row{
        height: 10px;
        border-radius: 8px;
        background: rgba(0,0,0,.07);
        margin: 10px 0;
      }
      .amg-skel-row.w2{ width: 66%; }
      .amg-skel-row.w3{ width: 84%; }
      .amg-skel-row.w4{ width: 52%; }

    `;
    document.documentElement.appendChild(s);
  }

  function applySettingsToUI() {
    document.documentElement.style.setProperty("--amg-banner-opacity", String(SETTINGS.bannerOpacity));
    document.documentElement.style.setProperty("--amg-panel-opacity", String(SETTINGS.panelOpacity));

    const b = document.getElementById(BANNER_ID);
    if (b) {
      const icon = b.querySelector(".ig-icon");
      if (icon) icon.setAttribute("data-glow", SETTINGS.enableBannerGlow ? "1" : "0");
    }

    const tb = document.getElementById(TOP_BADGE_ID);
    if (tb) tb.setAttribute("data-glow", SETTINGS.enableToolbarGlow ? "1" : "0");
  }

  function removeUI() {
    document.getElementById(BANNER_ID)?.remove();
    document.getElementById(PANEL_ID)?.remove();
  }

  // -------------------------
  // Provider detection
  // -------------------------
  const isGmail = () => location.hostname.includes("mail.google.com");
  const isOutlook = () =>
    location.hostname.includes("outlook.office.com") || location.hostname.includes("outlook.live.com");

  function providerName() {
    if (isGmail()) return "gmail";
    if (isOutlook()) return "outlook";
    return "unknown";
  }

  // -------------------------
  // Toolbar live icon (Gmail + Outlook)
  // -------------------------
  function injectGmailTopIndicator() {
    if (!isGmail()) return;

    if (!SETTINGS.showToolbarLiveIcon) {
      document.getElementById(TOP_BADGE_ID)?.remove();
      return;
    }
    if (document.getElementById(TOP_BADGE_ID)) {
      applySettingsToUI();
      return;
    }

    const iconUrl = chrome.runtime.getURL("assets/icon48.png");

    // Primary: pagination arrows area
    const older = document.querySelector('[aria-label="Older"], [data-tooltip="Older"]');
    const newer = document.querySelector('[aria-label="Newer"], [data-tooltip="Newer"]');

    let navContainer = null;
    if (older) navContainer = older.closest('div[role="navigation"]') || older.parentElement;
    if (!navContainer && newer) navContainer = newer.closest('div[role="navigation"]') || newer.parentElement;

    // Fallback: find the "X–Y of Z" node in header and attach near it
    if (!navContainer) {
      const nodes = Array.from(document.querySelectorAll("span, div")).slice(0, 700);
      const rangeNode =
        nodes.find((n) => /\b\d+\s*[–-]\s*\d+\s+of\s+\d+\b/i.test((n.textContent || "").trim())) || null;
      navContainer = rangeNode ? rangeNode.parentElement || null : null;
    }
    if (!navContainer) return;

    const badge = document.createElement("span");
    badge.id = TOP_BADGE_ID;
    badge.title = "AI Mail Genie is live (AI runs only when you click Assistant).";
    badge.setAttribute("data-glow", SETTINGS.enableToolbarGlow ? "1" : "0");
    badge.innerHTML = `<img alt="AI Mail Genie" src="${iconUrl}">`;

    navContainer.insertBefore(badge, navContainer.firstChild);
  }

  function injectOutlookTopIndicator() {
    if (!isOutlook()) return;

    if (!SETTINGS.showToolbarLiveIcon) {
      document.getElementById(TOP_BADGE_ID)?.remove();
      return;
    }
    if (document.getElementById(TOP_BADGE_ID)) {
      applySettingsToUI();
      return;
    }

    const iconUrl = chrome.runtime.getURL("assets/icon48.png");

    const toolbars = Array.from(document.querySelectorAll('div[role="toolbar"], div[role="menubar"], header'))
      .map((el) => ({ el, r: el.getBoundingClientRect() }))
      .filter((x) => x.r.top >= 0 && x.r.top < 140 && x.r.width > 300)
      .sort((a, b) => a.r.top - b.r.top);

    const container = toolbars[0]?.el || null;

    const badge = document.createElement("span");
    badge.id = TOP_BADGE_ID;
    badge.title = "AI Mail Genie is live (AI runs only when you click Assistant).";
    badge.setAttribute("data-glow", SETTINGS.enableToolbarGlow ? "1" : "0");
    badge.innerHTML = `<img alt="AI Mail Genie" src="${iconUrl}">`;

    if (container) {
      container.appendChild(badge);
    } else {
      badge.style.position = "fixed";
      badge.style.top = "12px";
      badge.style.right = "70px";
      badge.style.zIndex = "2147483646";
      document.body.appendChild(badge);
    }
  }

  function injectTopIndicatorByProvider() {
    if (isGmail()) injectGmailTopIndicator();
    else if (isOutlook()) injectOutlookTopIndicator();
  }

  // -------------------------
  // Banner draggable + position storage
  // -------------------------
  async function applySavedBannerPosition(banner) {
    const pos = await loadBannerPos();
    if (!pos) {
      banner.style.top = "10px";
      banner.style.right = "12px";
      banner.style.left = "auto";
      banner.style.bottom = "auto";
      return;
    }
    banner.style.left = `${Math.max(0, pos.left)}px`;
    banner.style.top = `${Math.max(0, pos.top)}px`;
    banner.style.right = "auto";
    banner.style.bottom = "auto";
  }

  function attachDragHandlers(banner) {
    let dragging = false;
    let startX = 0,
      startY = 0;
    let startLeft = 0,
      startTop = 0;

    const onMouseMove = (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      const newLeft = Math.max(0, Math.min(window.innerWidth - banner.offsetWidth, startLeft + dx));
      const newTop = Math.max(0, Math.min(window.innerHeight - banner.offsetHeight, startTop + dy));

      banner.style.left = `${newLeft}px`;
      banner.style.top = `${newTop}px`;
      banner.style.right = "auto";
      banner.style.bottom = "auto";
    };

    const onMouseUp = async () => {
      if (!dragging) return;
      dragging = false;
      banner.classList.remove("dragging");

      const rect = banner.getBoundingClientRect();
      await saveBannerPos({ left: rect.left, top: rect.top });

      window.removeEventListener("mousemove", onMouseMove, true);
      window.removeEventListener("mouseup", onMouseUp, true);
    };

    banner.addEventListener("mousedown", (e) => {
      if (e.target.closest("button, textarea, input, select, a, [role='button']")) return;
      const settings = document.getElementById(SETTINGS_ID);
      if (settings && settings.classList.contains("open") && settings.contains(e.target)) return;

      e.preventDefault();
      dragging = true;
      banner.classList.add("dragging");

      const rect = banner.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;

      window.addEventListener("mousemove", onMouseMove, true);
      window.addEventListener("mouseup", onMouseUp, true);
    });
  }

  // -------------------------
  // Settings UI
  // -------------------------
  function upsertSettingsPopover(banner) {
    let s = banner.querySelector(`#${SETTINGS_ID}`);
    if (s) return s;

    s = document.createElement("div");
    s.id = SETTINGS_ID;
    s.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
        <div style="font-weight:950;font-size:13px;color: rgba(15,23,42,.92);">AI Mail Genie Settings</div>
        <button class="sbtn" id="amg_s_close">Close</button>
      </div>

      <div class="row">
        <div>
          <div class="label">Banner opacity</div>
          <div class="desc">Controls transparency of the top banner</div>
        </div>
        <input type="range" id="amg_banner_op" min="60" max="100" value="${Math.round(
          SETTINGS.bannerOpacity * 100
        )}">
      </div>

      <div class="row">
        <div>
          <div class="label">Panel opacity</div>
          <div class="desc">Controls transparency of the assistant panel</div>
        </div>
        <input type="range" id="amg_panel_op" min="60" max="100" value="${Math.round(
          SETTINGS.panelOpacity * 100
        )}">
      </div>

      <div class="row">
        <div>
          <div class="label">Soft banner glow</div>
          <div class="desc">Subtle glow on banner icon</div>
        </div>
        <div class="toggle">
          <input type="checkbox" id="amg_banner_glow" ${SETTINGS.enableBannerGlow ? "checked" : ""}>
        </div>
      </div>

      <div class="row">
        <div>
          <div class="label">Show inbox live icon</div>
          <div class="desc">Shows the glowing icon in inbox toolbar</div>
        </div>
        <div class="toggle">
          <input type="checkbox" id="amg_toolbar_show" ${SETTINGS.showToolbarLiveIcon ? "checked" : ""}>
        </div>
      </div>

      <div class="row">
        <div>
          <div class="label">Inbox icon glow</div>
          <div class="desc">Pulse effect for inbox toolbar icon</div>
        </div>
        <div class="toggle">
          <input type="checkbox" id="amg_toolbar_glow" ${SETTINGS.enableToolbarGlow ? "checked" : ""}>
        </div>
      </div>

      <div style="margin-top:10px;padding-top:10px;border-top:1px solid rgba(0,0,0,.08);">
        <div class="label">Plan</div>
        <div class="desc" id="amg_plan_desc"></div>
        <div class="desc" style="margin-top:6px;">Device ID: <span style="font-family:ui-monospace;">${escapeHtml(
          DEVICE_ID || ""
        )}</span></div>
      </div>

      <div class="actions">
        <button class="sbtn" id="amg_clear_license">Clear product key</button>
      </div>
    `;
    banner.appendChild(s);

    const planDesc = s.querySelector("#amg_plan_desc");
    planDesc.textContent = PLAN_MODE === "pro" ? `Pro • strictness: ${STRICTNESS}` : `Free • follow-ups + full findings locked`;

    s.querySelector("#amg_s_close").addEventListener("click", () => s.classList.remove("open"));

    const bannerOp = s.querySelector("#amg_banner_op");
    bannerOp.addEventListener("input", async () => {
      SETTINGS.bannerOpacity = Number(bannerOp.value) / 100;
      await saveSettings(SETTINGS);
      applySettingsToUI();
    });

    const panelOp = s.querySelector("#amg_panel_op");
    panelOp.addEventListener("input", async () => {
      SETTINGS.panelOpacity = Number(panelOp.value) / 100;
      await saveSettings(SETTINGS);
      applySettingsToUI();
    });

    const bannerGlow = s.querySelector("#amg_banner_glow");
    bannerGlow.addEventListener("change", async () => {
      SETTINGS.enableBannerGlow = !!bannerGlow.checked;
      await saveSettings(SETTINGS);
      applySettingsToUI();
    });

    const toolbarShow = s.querySelector("#amg_toolbar_show");
    toolbarShow.addEventListener("change", async () => {
      SETTINGS.showToolbarLiveIcon = !!toolbarShow.checked;
      await saveSettings(SETTINGS);
      injectTopIndicatorByProvider();
    });

    const toolbarGlow = s.querySelector("#amg_toolbar_glow");
    toolbarGlow.addEventListener("change", async () => {
      SETTINGS.enableToolbarGlow = !!toolbarGlow.checked;
      await saveSettings(SETTINGS);
      applySettingsToUI();
    });

    s.querySelector("#amg_clear_license").addEventListener("click", async () => {
      await sendToBackground({ type: "AMG_CLEAR_LICENSE" });
      await savePlan("free", "normal");
      await refreshStatusFromBackground();
      s.remove();
      applyPlanGatingUI();
      alert("Product key cleared. You are now in Free mode.");
    });

    return s;
  }

  // -------------------------
  // Banner + Panel
  // -------------------------
  function upsertBanner() {
    ensureStyles();

    let b = document.getElementById(BANNER_ID);
    if (!b) {
      b = document.createElement("div");
      b.id = BANNER_ID;
      b.innerHTML = `
        <div class="ig-top">
          <div class="ig-icon"><img alt="AI Mail Genie" src="${chrome.runtime.getURL("assets/icon48.png")}"></div>
          <div style="min-width:0;">
            <div class="ig-title" id="amg_title"></div>
            <div class="ig-sub" id="amg_sub"></div>
          </div>
          <div class="ig-actions">
            <button class="ig-btn" id="amg_assistant">Assistant</button>
            <button class="ig-btn" id="amg_settings">Settings</button>
            <button class="ig-btn" id="amg_dismiss">Dismiss</button>
          </div>
        </div>
      `;
      document.body.appendChild(b);

      applySavedBannerPosition(b);
      attachDragHandlers(b);

      b.querySelector("#amg_assistant").addEventListener("click", () => openPanelForCurrentEmail({ forceRefresh: false }));
      b.querySelector("#amg_dismiss").addEventListener("click", () => b.remove());
      b.querySelector("#amg_settings").addEventListener("click", () => {
        const pop = upsertSettingsPopover(b);
        pop.classList.toggle("open");
      });

      document.addEventListener("mousedown", (e) => {
        const pop = b.querySelector(`#${SETTINGS_ID}`);
        if (!pop || !pop.classList.contains("open")) return;
        if (pop.contains(e.target)) return;
        if (e.target.closest("#amg_settings")) return;
        pop.classList.remove("open");
      });

      applySettingsToUI();
    }

    b.querySelector("#amg_title").textContent = "AI analysis available";
    b.querySelector("#amg_sub").textContent = "Click Assistant to analyze this email";

    const icon = b.querySelector(".ig-icon");
    if (icon) icon.setAttribute("data-glow", SETTINGS.enableBannerGlow ? "1" : "0");

    return b;
  }

  function ensurePanel() {
    ensureStyles();
    let p = document.getElementById(PANEL_ID);
    if (p) return p;

    p = document.createElement("div");
    p.id = PANEL_ID;
    p.innerHTML = `
      <div class="p-head">
        <div style="min-width:0;">
          <div class="p-title">AI Mail Genie Assistant</div>
          <div class="p-meta" id="amg_meta"></div>
        
        </div>
        <div class="p-right">
          <div class="p-count" id="amg_count"></div>
          <div class="p-modes" id="amg_modes" title="Choose analysis mode">
            <button class="p-modebtn" id="amg_mode_personal" data-mode="personal" type="button">Personal</button>
            <button class="p-modebtn" id="amg_mode_business" data-mode="business" type="button">Business</button>
          </div>
          <button class="p-close" id="amg_close">Close</button>
        </div>

      </div>

      <div class="p-body" id="amg_body"></div>

      <div class="hint" id="amg_hint"></div>

      <div class="p-foot" id="amg_footer">
        <div class="foot-row" id="amg_pro_row">
          <textarea id="amg_input" placeholder="Ask a question…"></textarea>
          <button class="send" id="amg_send">Send</button>
        </div>

        <div class="free-cta" id="amg_free_cta">
          <div>
            <div class="t1">Upgrade to Pro to ask follow-up questions</div>
            <div class="t2">Get deeper explanations, “what if” scenarios, and action templates.</div>
          </div>
          <div class="row2">
            <input id="amg_license_input" placeholder="Enter Product Key if you already purchased" />
            <button class="apply" id="amg_apply_key">Apply</button>
            <button class="upgrade" id="amg_upgrade">Upgrade to Pro</button>
          </div>
          <div class="msg2" id="amg_license_status"></div>
        </div>
      </div>
    `;
    document.documentElement.appendChild(p);

    p.querySelector("#amg_close").addEventListener("click", () => p.classList.remove("open"));


// Mode toggle (Personal / Business)
const syncModeButtons = () => {
  const mode = getAnalysisMode();
  const b1 = p.querySelector("#amg_mode_personal");
  const b2 = p.querySelector("#amg_mode_business");
  if (b1) b1.setAttribute("data-active", mode === "personal" ? "1" : "0");
  if (b2) b2.setAttribute("data-active", mode === "business" ? "1" : "0");
};

const setMode = async (mode) => {
  const next = String(mode || "").toLowerCase() === "business" ? "business" : "personal";
  if (!SETTINGS) SETTINGS = await loadSettings();
  if (SETTINGS.analysisMode === next) return;
  SETTINGS.analysisMode = next;
  await saveSettings(SETTINGS);
  syncModeButtons();
  // Re-render current panel content without altering chat history
  if (Array.isArray(LAST_RENDERED_MESSAGES)) renderMessages(LAST_RENDERED_MESSAGES);
};

const personalBtn = p.querySelector("#amg_mode_personal");
const businessBtn = p.querySelector("#amg_mode_business");
if (personalBtn) personalBtn.addEventListener("click", () => setMode("personal"));
if (businessBtn) businessBtn.addEventListener("click", () => setMode("business"));
syncModeButtons();


    p.querySelector("#amg_send").addEventListener("click", () => onSend());
    p.querySelector("#amg_input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        onSend();
      }
    });

    p.querySelector("#amg_upgrade").addEventListener("click", openUpgrade);

    p.querySelector("#amg_apply_key").addEventListener("click", async () => {
      const input = p.querySelector("#amg_license_input");
      const status = p.querySelector("#amg_license_status");
      const key = normalizeText(input.value);

      if (!key) {
        status.textContent = "Enter a Product Key first.";
        return;
      }

      status.textContent = "Validating key…";

      const resp = await sendToBackground({ type: "AMG_SAVE_LICENSE", licenseKey: key });

      if (!resp?.ok) {
        // Keep user in Free mode on invalid key
        LICENSE_KEY = "";
        applyPlanToRuntime({ mode: "free", tier: "free", expiresAt: null, strictness: STRICTNESS || "normal" });
        await savePlanFull(PLAN);
        applyPlanGatingUI();
        status.textContent = `Invalid key: ${resp?.error || "invalid_license"}`;
        return;
      }

      LICENSE_KEY = (resp.licenseKey || key || "").trim();
      DEVICE_ID = (resp.deviceId || DEVICE_ID || "").trim();

      // Server-authoritative plan
      const plan = resp.plan || { mode: "pro", tier: "lifetime", expiresAt: null, strictness: "normal" };
      applyPlanToRuntime(plan);
      await savePlanFull(PLAN);

      const tierLabel =
        PLAN_MODE === "pro"
          ? (PLAN_TIER === "monthly" ? "Monthly" : PLAN_TIER === "yearly" ? "Yearly" : "Lifetime")
          : "Free";

      const expLabel =
        PLAN_MODE === "pro" && PLAN_EXPIRES_AT ? ` (expires ${new Date(PLAN_EXPIRES_AT).toLocaleDateString()})` : "";

      status.textContent = PLAN_MODE === "pro"
        ? `Activated: Pro (${tierLabel})${expLabel}. Re-checking this email now…`
        : "Key saved, but not eligible for Pro.";

      applyPlanGatingUI();
      // Force fresh analysis so UI reflects plan immediately
      await rerunAnalysisForCurrentEmail();
    });

    // Prefill stored license key when panel opens
    setTimeout(() => {
      const inp = p.querySelector("#amg_license_input");
      if (inp && LICENSE_KEY) inp.value = LICENSE_KEY;
    }, 0);

    applySettingsToUI();
    applyPlanGatingUI();
    return p;
  }

  function applyPlanGatingUI() {
    const p = document.getElementById(PANEL_ID);
    if (!p) return;

    const hint = p.querySelector("#amg_hint");
    const count = p.querySelector("#amg_count");

    const proRow = p.querySelector("#amg_pro_row");
    const freeCta = p.querySelector("#amg_free_cta");

    const input = p.querySelector("#amg_input");
    const send = p.querySelector("#amg_send");

    const isPro = PLAN_MODE === "pro";

    if (!isPro) {
      if (proRow) proRow.style.display = "none";
      if (freeCta) freeCta.classList.add("open");

      if (input) input.disabled = true;
      if (send) send.disabled = true;

      if (hint) hint.textContent = "";
      if (count) count.textContent = "Free";
    } else {
      if (freeCta) freeCta.classList.remove("open");
      if (proRow) proRow.style.display = "flex";

      if (input) input.disabled = false;
      if (send) send.disabled = false;

      if (hint) hint.textContent = "Pro plan: ask questions and get deeper explanations.";
      if (count) {
        const tierLabel = PLAN_TIER === "monthly" ? "Pro (Monthly)" : PLAN_TIER === "yearly" ? "Pro (Yearly)" : PLAN_TIER === "lifetime" ? "Pro (Lifetime)" : "Pro";
        count.textContent = tierLabel;
      }
    }
  }

  
  function clamp(n, a, b) {
    return Math.max(a, Math.min(b, n));
  }

  function computeConfidenceFromState(state) {
    // Confidence here is a UI heuristic (not an authentication guarantee).
    // We base it on available provider signals and observable indicators.
    const p = state?.aiPayload || {};
    const senderDomain = (state?.senderDomain || "").toLowerCase();
    const mailedBy = (p.mailedBy || "").toLowerCase();
    const signedBy = (p.signedBy || "").toLowerCase();

    let score = 52;

    // Positive signals
    if (p.gmailVerifiedSender) score += 18;
    if (signedBy) score += 14; // DKIM present
    if (mailedBy) score += 6;

    // Domain alignment (best-effort)
    if (senderDomain && mailedBy) {
      const a = getBaseDomain(senderDomain);
      const b = getBaseDomain(mailedBy);
      if (a && b && a === b) score += 6;
      if (a && b && a !== b) score -= 10;
    }
    if (senderDomain && signedBy) {
      const a = getBaseDomain(senderDomain);
      const b = getBaseDomain(signedBy);
      if (a && b && a === b) score += 6;
      if (a && b && a !== b) score -= 8;
    }

    // Risk signals
    const externalLinks = (p.linkUrls || []).length;
    if (externalLinks >= 3) score -= 10;
    else if (externalLinks === 2) score -= 6;
    else if (externalLinks === 1) score -= 3;

    if (p.paymentChanged) score -= 14;

    // If we have link domains that clearly differ from sender, treat as additional risk
    const linkDomains = Array.isArray(p.linkDomains) ? p.linkDomains : [];
    if (senderDomain && linkDomains.length) {
      const senderBase = getBaseDomain(senderDomain);
      const mismatches = linkDomains.filter((d) => getBaseDomain(d) && getBaseDomain(d) !== senderBase);
      if (mismatches.length >= 2) score -= 10;
      else if (mismatches.length === 1) score -= 6;
    }


// Scam keyword patterns (fast local phishing detection)
const kw = detectPaymentScamKeywords(`${state?.subject || ""}\n${state?.bodyText || ""}`);
if (kw.accountThreat) score -= 18;
if (kw.paymentFailure) score -= 18;
if (kw.loginHarvest) score -= 14;
if (kw.prizeScam) score -= 18;
if (kw.urgency) score -= 8;

// Local sender policy overrides
if (isSenderBlocked(state)) score = 4;
if (isSenderWhitelisted(state)) score = Math.max(score, 90);

    score = clamp(score, 4, 96);

    let label = "Medium";
    if (score >= 78) label = "High";
    else if (score <= 44) label = "Low";

    return { score, label };
  }

  async function copyTextToClipboard(text) {
    const t = String(text || "");
    try {
      await navigator.clipboard.writeText(t);
      return true;
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = t;
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        return !!ok;
      } catch {
        return false;
      }
    }
  }

  async function shareText({ title, text }) {
    const t = String(text || "");
    try {
      if (navigator.share) {
        await navigator.share({ title: title || "AI Mail Genie", text: t });
        return true;
      }
    } catch {
      // fall through
    }
    // Fallback: copy
    return await copyTextToClipboard(t);
  }

  function el(tag, cls, txt) {
    const d = document.createElement(tag);
    if (cls) d.className = cls;
    if (txt !== undefined) d.textContent = txt;
    return d;
  }

  function makeBadge(label, kind) {
    const b = el("span", `amg-badge ${kind || "neutral"}`, label);
    return b;
  }

  function makeMiniButton(label, onClick) {
    const btn = el("button", "amg-mini-btn", label);
    btn.type = "button";
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick?.();
    });
    return btn;
  }

  function makeSection({ title, bodyText, openDefault }) {
    const wrap = el("div", "amg-sec");
    wrap.setAttribute("data-open", openDefault ? "1" : "0");

    const h = el("div", "amg-sec-h");
    const t = el("div", "amg-sec-title", title);
    const toggle = el("button", "amg-sec-btn", openDefault ? "Collapse" : "Expand");
    toggle.type = "button";

    const body = el("div", "amg-sec-body");
    body.textContent = bodyText || "";

    const setOpen = (isOpen) => {
      wrap.setAttribute("data-open", isOpen ? "1" : "0");
      toggle.textContent = isOpen ? "Collapse" : "Expand";
    };

    h.addEventListener("click", () => setOpen(wrap.getAttribute("data-open") !== "1"));
    toggle.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      setOpen(wrap.getAttribute("data-open") !== "1");
    });

    h.appendChild(t);
    h.appendChild(toggle);
    wrap.appendChild(h);
    wrap.appendChild(body);
    return wrap;
  }

  function splitSummaryAndDetails(text) {
    const s = String(text || "").trim();
    if (!s) return { summary: "", details: "" };
    const parts = s.split(/\n\s*\n/);
    if (parts.length === 1) return { summary: parts[0].trim(), details: "" };
    const summary = parts[0].trim();
    const details = parts.slice(1).join("\n\n").trim();
    return { summary, details };
  }

  function buildPremiumOverviewCard(state) {
    const card = el("div", "amg-card");
    const head = el("div", "amg-card-h");
    const left = el("div", "");
    const title = el("div", "amg-card-title", "Email signals");
    left.appendChild(title);

    const badges = el("div", "amg-badges");
    const p = state?.aiPayload || {};
    if (p.gmailVerifiedSender) badges.appendChild(makeBadge("Verified sender", "good"));
    if (p.signedBy) badges.appendChild(makeBadge("DKIM", "good"));
    if (p.mailedBy && p.signedBy && getBaseDomain(p.mailedBy) !== getBaseDomain(p.signedBy)) {
      badges.appendChild(makeBadge("Auth mismatch", "warn"));
    }
    if (p.paymentChanged) badges.appendChild(makeBadge("Payment details changed", "warn"));
    if ((p.linkUrls || []).length) badges.appendChild(makeBadge(`Links: ${(p.linkUrls || []).length}`, "neutral"));
    head.appendChild(left);

    const actions = el("div", "amg-card-actions");
    actions.appendChild(badges);
    head.appendChild(actions);

    const body = el("div", "amg-card-b");

    const { score, label } = computeConfidenceFromState(state);
    const confWrap = el("div", "amg-conf-wrap");
    const confLabel = el("div", "amg-conf-label", `Confidence: ${label} (${score}%)`);
    const bar = el("div", "amg-conf-bar");
    const fill = el("div", "amg-conf-fill");
    fill.style.width = `${score}%`;
    fill.style.background = confidenceColorFromScore(score);
    fill.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.04) inset';
    bar.appendChild(fill);
    confWrap.appendChild(confLabel);
    confWrap.appendChild(bar);

    const kv = el("div", "amg-kv");
    const addKV = (k, v) => {
      const kk = el("div", "k", k);
      const vv = el("div", "v", v || "—");
      kv.appendChild(kk);
      kv.appendChild(vv);
    };

    addKV("From", state?.senderEmail || "—");
    addKV("Sender domain", state?.senderDomain || "—");
    addKV("Mailed-by", p.mailedBy || "—");
    addKV("Signed-by", p.signedBy || "—");
    addKV("External links", String((p.linkUrls || []).length));
    addKV("Link domains", (Array.isArray(p.linkDomains) && p.linkDomains.length ? p.linkDomains.join(", ") : "—"));

    body.appendChild(kv);
    body.appendChild(confWrap);

    card.appendChild(head);
    card.appendChild(body);
    return card;
  }

  function buildSkeletonCard(label) {
    const card = el("div", "amg-card amg-skel");
    const head = el("div", "amg-card-h");
    head.appendChild(el("div", "amg-card-title", label || "Analyzing"));
    card.appendChild(head);

    const b = el("div", "amg-card-b");
    const r1 = el("div", "amg-skel-row w3");
    const r2 = el("div", "amg-skel-row w2");
    const r3 = el("div", "amg-skel-row w4");
    const r4 = el("div", "amg-skel-row w3");
    b.appendChild(r1); b.appendChild(r2); b.appendChild(r3); b.appendChild(r4);
    card.appendChild(b);
    return card;
  }

  function buildAssistantPremiumCard(text) {
    const card = el("div", "amg-card amg-ai-card");
    const head = el("div", "amg-card-h");
    const title = el("div", "amg-card-title", "AI analysis");
    head.appendChild(title);

    const actions = el("div", "amg-card-actions");
    actions.appendChild(makeMiniButton("Copy", async () => {
      await copyTextToClipboard(text || "");
    }));
    actions.appendChild(makeMiniButton("Share", async () => {
      await shareText({ title: "AI Mail Genie", text: text || "" });
    }));
    head.appendChild(actions);
    card.appendChild(head);

    const b = el("div", "amg-card-b");
    const { summary, details } = splitSummaryAndDetails(text);

    const sections = el("div", "amg-sections");
    if (summary) sections.appendChild(makeSection({ title: "Summary", bodyText: summary, openDefault: true }));
    if (details) sections.appendChild(makeSection({ title: "Details", bodyText: details, openDefault: false }));
    if (!summary && !details) sections.appendChild(makeSection({ title: "Details", bodyText: "", openDefault: true }));

    b.appendChild(sections);
    card.appendChild(b);
    return card;
  }

  
function buildBusinessProtectionCard(state) {
  const card = el("div", "amg-card");
  const head = el("div", "amg-card-h");
  const left = el("div", "");
  left.appendChild(el("div", "amg-card-title", "Business protection"));
  left.appendChild(el("div", "amg-card-sub", "Invoice fraud • impersonation • payment redirection"));
  head.appendChild(left);

  const actions = el("div", "amg-card-actions");
  const copyBtn = makeMiniButton("Copy evidence", async () => {
    const bundle = buildBusinessEvidenceBundle(state);
    await copyTextToClipboard(bundle);
  });
  actions.appendChild(copyBtn);

const allowBtn = makeMiniButton("Whitelist", async () => {
  const keyEmail = normSenderKey(state?.senderEmail);
  const keyDomain = normSenderKey(state?.senderDomain) || normSenderKey(getBaseDomain(state?.senderDomain));
  const key = keyEmail || keyDomain;
  if (!key) return;
  SENDER_BLOCKLIST = SENDER_BLOCKLIST.filter((x) => x !== key);
  if (!SENDER_ALLOWLIST.includes(key)) SENDER_ALLOWLIST.push(key);
  await saveSenderLists();
  renderMessages(LAST_RENDERED_MESSAGES);
});
const blockBtn = makeMiniButton("Block", async () => {
  const keyEmail = normSenderKey(state?.senderEmail);
  const keyDomain = normSenderKey(state?.senderDomain) || normSenderKey(getBaseDomain(state?.senderDomain));
  const key = keyEmail || keyDomain;
  if (!key) return;
  SENDER_ALLOWLIST = SENDER_ALLOWLIST.filter((x) => x !== key);
  if (!SENDER_BLOCKLIST.includes(key)) SENDER_BLOCKLIST.push(key);
  await saveSenderLists();
  renderMessages(LAST_RENDERED_MESSAGES);
});

// Visual state
if (isSenderWhitelisted(state)) {
  allowBtn.setAttribute("data-active", "1");
  allowBtn.textContent = "Whitelisted";
}
if (isSenderBlocked(state)) {
  blockBtn.setAttribute("data-active", "1");
  blockBtn.textContent = "Blocked";
}

actions.appendChild(allowBtn);
actions.appendChild(blockBtn);
  head.appendChild(actions);

  const body = el("div", "amg-card-b");
  const res = computeBusinessRisk(state);

  // Local sender policy overrides
  if (isSenderBlocked(state)) {
    res.identityRisk = Math.max(res.identityRisk, 80);
    res.paymentRisk = Math.max(res.paymentRisk, 90);
    res.drivers = ["Sender is blocked locally.", ...res.drivers];
    res.badges = [{ label: "Blocked", kind: "warn" }, ...res.badges];
    res.nextSteps = ["Do not interact with this email (no links, no attachments).", "Report phishing in Gmail and delete the message.", ...res.nextSteps];
  } else if (isSenderWhitelisted(state)) {
    res.identityRisk = Math.min(res.identityRisk, 10);
    res.paymentRisk = Math.min(res.paymentRisk, 10);
    res.badges = [{ label: "Whitelisted", kind: "good" }, ...res.badges];
  }

  // Badges
  const badges = el("div", "amg-badges");
  for (const b of res.badges) badges.appendChild(makeBadge(b.label, b.kind));
  body.appendChild(badges);

  // Risk bars
  body.appendChild(buildRiskBar("Identity risk", res.identityRisk));
  body.appendChild(buildRiskBar("Payment fraud risk", res.paymentRisk));

  // Sections
  body.appendChild(makeSection({
    title: "Why this was flagged",
    bodyText: res.drivers.length ? ("• " + res.drivers.join("\n• ")) : "No high-risk indicators detected.",
    openDefault: true
  }));

  body.appendChild(makeSection({
    title: "Recommended next steps",
    bodyText: res.nextSteps.length ? ("• " + res.nextSteps.join("\n• ")) : "No action needed.",
    openDefault: true
  }));

  body.appendChild(makeSection({
    title: "Detected payment identifiers (masked)",
    bodyText: res.identifiers.length ? ("• " + res.identifiers.join("\n• ")) : "None detected.",
    openDefault: false
  }));

  card.appendChild(head);
  card.appendChild(body);
  return card;
}
function buildSenderControlsCard(state) {
  const card = el("div", "amg-card");
  const head = el("div", "amg-card-h");
  head.appendChild(el("div", "amg-card-title", "Sender controls"));
  const actions = el("div", "amg-card-actions");

  const allowBtn = makeMiniButton("Whitelist", async () => {
    const keyEmail = normSenderKey(state?.senderEmail);
    const keyDomain = normSenderKey(state?.senderDomain) || normSenderKey(getBaseDomain(state?.senderDomain));
    const key = keyEmail || keyDomain;
    if (!key) return;
    SENDER_BLOCKLIST = SENDER_BLOCKLIST.filter((x) => x !== key);
    if (!SENDER_ALLOWLIST.includes(key)) SENDER_ALLOWLIST.push(key);
    await saveSenderLists();
    renderMessages(LAST_RENDERED_MESSAGES);
  });

  const blockBtn = makeMiniButton("Block", async () => {
    const keyEmail = normSenderKey(state?.senderEmail);
    const keyDomain = normSenderKey(state?.senderDomain) || normSenderKey(getBaseDomain(state?.senderDomain));
    const key = keyEmail || keyDomain;
    if (!key) return;
    SENDER_ALLOWLIST = SENDER_ALLOWLIST.filter((x) => x !== key);
    if (!SENDER_BLOCKLIST.includes(key)) SENDER_BLOCKLIST.push(key);
    await saveSenderLists();
    renderMessages(LAST_RENDERED_MESSAGES);
  });

  if (isSenderWhitelisted(state)) {
    allowBtn.setAttribute("data-active","1");
    allowBtn.textContent = "Whitelisted";
  }
  if (isSenderBlocked(state)) {
    blockBtn.setAttribute("data-active","1");
    blockBtn.textContent = "Blocked";
  }

  actions.appendChild(allowBtn);
  actions.appendChild(blockBtn);
  head.appendChild(actions);

  const body = el("div", "amg-card-b");
  const badges = el("div", "amg-badges");
  badges.appendChild(makeBadge(state?.senderDomain ? `Domain: ${state.senderDomain}` : "Domain: —", "neutral"));
  if (state?.senderEmail) badges.appendChild(makeBadge(`From: ${state.senderEmail}`, "neutral"));

  if (isSenderWhitelisted(state)) badges.appendChild(makeBadge("Whitelisted locally", "good"));
  if (isSenderBlocked(state)) badges.appendChild(makeBadge("Blocked locally", "warn"));

  body.appendChild(badges);

  if (isSenderBlocked(state)) {
    body.appendChild(el("div", "amg-note-warn", "This sender is blocked locally. Treat this email as high risk; do not click links or provide credentials."));
  } else if (isSenderWhitelisted(state)) {
    body.appendChild(el("div", "amg-note-ok", "This sender is whitelisted locally. You can still review signals, but warnings are reduced."));
  } else {
    body.appendChild(el("div", "amg-note", "Whitelist or block this sender for this device only (stored locally)."));
  }

  card.appendChild(head);
  card.appendChild(body);
  return card;
}




function riskColorFromScore(score) {
  // 0..100 risk scale:
  // dark green -> light green -> light yellow -> yellow -> light red -> dark red
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  const stops = [
    { p: 0,   c: [16, 122, 68] },   // dark green
    { p: 20,  c: [74, 222, 128] },  // light green
    { p: 40,  c: [254, 240, 138] }, // light yellow
    { p: 55,  c: [250, 204, 21] },  // yellow
    { p: 75,  c: [252, 165, 165] }, // light red
    { p: 100, c: [220, 38, 38] },   // dark red
  ];
  let a = stops[0], b = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (s >= stops[i].p && s <= stops[i + 1].p) { a = stops[i]; b = stops[i + 1]; break; }
  }
  const span = Math.max(1, (b.p - a.p));
  const t = (s - a.p) / span;
  const lerp = (x, y) => Math.round(x + (y - x) * t);
  const r = lerp(a.c[0], b.c[0]);
  const g = lerp(a.c[1], b.c[1]);
  const bl = lerp(a.c[2], b.c[2]);
  return `rgb(${r}, ${g}, ${bl})`;
}

function confidenceColorFromScore(score) {
  // Confidence is a "goodness" metric: low => danger (red), high => safe (green).
  // We reuse the same risk gradient but invert the score.
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  return riskColorFromScore(100 - s);
}
function buildRiskBar(label, score) {
  const wrap = el("div", "amg-conf-wrap");
  const clamped = Math.max(0, Math.min(100, Number(score) || 0));
  const txt = clamped >= 70 ? "High" : clamped >= 35 ? "Caution" : "Low";
  wrap.appendChild(el("div", "amg-conf-label", `${label}: ${txt} (${clamped}%)`));
  const bar = el("div", "amg-conf-bar");
  const fill = el("div", "amg-conf-fill");
  fill.style.width = `${clamped}%`;
  fill.style.background = riskColorFromScore(clamped);
  fill.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.04) inset';
bar.appendChild(fill);
  wrap.appendChild(bar);
  return wrap;
}

function computeBusinessRisk(state) {
  const p = state?.aiPayload || {};
  const body = String(state?.bodyText || "");
  const subj = String(state?.subject || "");
  const senderDomain = String(state?.senderDomain || "");

  const identityDrivers = [];
  const payDrivers = [];
  const badges = [];

  // Identity / auth consistency (uses existing extracted signals)
  const fromBase = getBaseDomain(senderDomain);
  const mailedBase = getBaseDomain(p.mailedBy || "");
  const signedBase = getBaseDomain(p.signedBy || "");

  if (p.gmailVerifiedSender) {
    badges.push({ label: "Verified sender", kind: "good" });
  }
  if (p.signedBy) {
    badges.push({ label: "DKIM", kind: "good" });
  }

  let identityRisk = 0;
  if (p.mailedBy && fromBase && mailedBase && mailedBase !== fromBase) {
    identityRisk += 15;
    identityDrivers.push(`Mailed-by domain differs from sender domain (${p.mailedBy} vs ${senderDomain}).`);
    badges.push({ label: "Mailed-by mismatch", kind: "warn" });
  }
  if (p.signedBy && fromBase && signedBase && signedBase !== fromBase) {
    identityRisk += 25;
    identityDrivers.push(`Signed-by domain differs from sender domain (${p.signedBy} vs ${senderDomain}).`);
    badges.push({ label: "Signed-by mismatch", kind: "warn" });
  }
  if (p.mailedBy && p.signedBy && mailedBase && signedBase && mailedBase !== signedBase) {
    identityRisk += 15;
    identityDrivers.push(`Authentication domains disagree (mailed-by ${p.mailedBy} vs signed-by ${p.signedBy}).`);
    badges.push({ label: "Auth mismatch", kind: "warn" });
  }
  if (!p.signedBy) {
    identityRisk += 10;
    identityDrivers.push("DKIM / signed-by not detected in provider signals.");
  }

  // Payment / invoice heuristics (local-only)
  const kw = detectPaymentScamKeywords(`${subj}\n${body}`);
  const ids = extractPaymentIdentifiers(body);

  
let paymentRisk = 0;

// Fast-path scam patterns (account deletion/payment failure/login harvesting/prize scams)
if (kw.accountThreat) {
  paymentRisk += 25;
  payDrivers.push("Account-closure/deletion threat language detected (common phishing pattern).");
  badges.push({ label: "Account threat", kind: "warn" });
}
if (kw.loginHarvest) {
  paymentRisk += 20;
  payDrivers.push("Login/verification call-to-action language detected (common phishing pattern).");
  badges.push({ label: "Verify / Login", kind: "warn" });
}
if (kw.prizeScam) {
  paymentRisk += 25;
  payDrivers.push("Prize/reward/claim language detected (common scam pattern).");
  badges.push({ label: "Prize scam", kind: "warn" });
}

// Sender patterns frequently used by fraud campaigns (numeric host / random domains / 'mail.store' style)
const se = String(state?.senderEmail || "").toLowerCase();
if (se && /\b\d{1,3}(?:\.\d{1,3}){2,3}\b/.test(se)) {
  identityRisk += 20;
  identityDrivers.push("Sender address contains an IP-like pattern (common in spoofed/bulk fraud campaigns).");
  badges.push({ label: "Suspicious sender", kind: "warn" });
}
if (senderDomain && /(mail\.store|store\.ass|\.biz\.ua|\.biz\b|\.xyz\b|\.top\b|\.icu\b)/.test(senderDomain)) {
  identityRisk += 10;
  identityDrivers.push("Sender domain pattern is uncommon for legitimate billing/security notifications.");
}

if (kw.bankChange) {

    paymentRisk += 35;
    payDrivers.push("Language indicates updated bank/payment details.");
    badges.push({ label: "Payment change request", kind: "warn" });
  }
  if (kw.invoice) {
    paymentRisk += 10;
    payDrivers.push("Invoice/billing language detected.");
    badges.push({ label: "Invoice terms", kind: "neutral" });
  }
  if (kw.urgency) {
    paymentRisk += 10;
    payDrivers.push("Urgency / pressure language detected.");
    badges.push({ label: "Urgent", kind: "warn" });
  }
  if (ids.length) {
    paymentRisk += 20;
    payDrivers.push("Payment identifiers present (bank/UPI/IBAN/IFSC/SWIFT/account number).");
    badges.push({ label: "Payment identifiers", kind: "warn" });
  }
  const linkCount = Array.isArray(p.linkUrls) ? p.linkUrls.length : 0;
  if (linkCount >= 3) {
    paymentRisk += 10;
    payDrivers.push(`Multiple external links detected (${linkCount}).`);
    badges.push({ label: `Links: ${linkCount}`, kind: "neutral" });
  }
  if (p.paymentChanged) {
    paymentRisk += 25;
    payDrivers.push("Payment details appear different from prior emails in this thread (local baseline).");
    badges.push({ label: "Payment details changed", kind: "warn" });
  }

  // --- Coupled decision logic for high-confidence fraud patterns ---
  const linkTrigger = linkCount >= 2;
  const suspiciousSenderNow =
    (se && /\b\d{1,3}(?:\.\d{1,3}){2,3}\b/.test(se)) ||
    (senderDomain && /(mail\.store|store\.ass|\.biz\.ua|\.biz\b|\.xyz\b|\.top\b|\.icu\b)/.test(senderDomain));

  const tier1Triggers = [
    kw.accountThreat,
    kw.paymentFailure,
    kw.loginHarvest,
    kw.prizeScam,
    kw.bankChange,
    kw.urgency,
    linkTrigger,
    suspiciousSenderNow,
  ].filter(Boolean).length;

  // If we have multiple strong scam indicators, escalate aggressively (no "maybe").
  if (tier1Triggers >= 2) {
    paymentRisk = Math.max(paymentRisk, 90);
    identityRisk = Math.max(identityRisk, 80);
    payDrivers.push("Multiple high-confidence scam indicators detected (rapid escalation).");
    badges.push({ label: "High-confidence scam", kind: "warn" });
  }

  // Payment fraud campaigns inherently require impersonation; couple the scores.
  if (paymentRisk >= 80) {
    identityRisk = Math.max(identityRisk, 70);
  }

  // Local sender policy overrides
  if (isSenderBlocked(state)) {
    identityRisk = 100;
    paymentRisk = 100;
    identityDrivers.push("Sender is blocked locally (policy override).");
    badges.push({ label: "Blocked", kind: "warn" });
  }
  if (isSenderWhitelisted(state)) {
    identityRisk = Math.min(identityRisk, 15);
    paymentRisk = Math.min(paymentRisk, 15);
    badges.push({ label: "Whitelisted", kind: "good" });
  }


  identityRisk = Math.max(0, Math.min(100, identityRisk));
  paymentRisk = Math.max(0, Math.min(100, paymentRisk));

  const drivers = [...identityDrivers, ...payDrivers];

  const nextSteps = [];
  const hi = identityRisk >= 50 || paymentRisk >= 50;
  const mid = !hi && (identityRisk >= 25 || paymentRisk >= 25);

  if (hi || mid) {
    nextSteps.push("Do not pay from this email. Verify details using a trusted channel (vendor master record / official portal).");
    nextSteps.push("Call the vendor using a previously known phone number (not the number in this email).");
    nextSteps.push("Compare banking/UPI/IFSC details with the last paid invoice or approved vendor record.");
    nextSteps.push("If in doubt, escalate to finance/security and report phishing.");
  } else {
    nextSteps.push("No high-risk indicators detected. Continue standard verification practices for payments.");
  }

  return {
    identityRisk,
    paymentRisk,
    drivers,
    nextSteps,
    identifiers: ids,
    badges
  };
}

function detectPaymentScamKeywords(text) {
  const t = String(text || "").toLowerCase();
  const has = (arr) => arr.some((w) => t.includes(w));

  // Business payment / invoice
  const invoice = has([
    "invoice","proforma","bill","billing","payment due","overdue","remit","remittance",
    "purchase order","po #","po-","statement","receipt","transaction","renew","renewal"
  ]);

  const bankChange = has([
    "updated bank","new bank","change bank","change of bank","new beneficiary","change of beneficiary",
    "updated payment","update payment","update your payment","payment information","bank details","account details",
    "wire to","ach","iban","swift","bic","ifsc","upi"
  ]);

  const urgency = has([
    "urgent","immediately","asap","today","within 24 hours","within 48 hours","final notice","final reminder",
    "action required","action required","account will be","will be deleted","closed","blocked","suspended","limited","terminated"
  ]);

  // Common phishing / account takeover themes (seen in your screenshots)
  const accountThreat = has([
    "your cloud data is at immediate risk","risk of deletion","will be deleted","photos and videos will be deleted",
    "we've blocked your account","we have blocked your account","account will be closed","account security",
    "subscription termination","subscription has closed","payment processing failed","payment declined",
    "unable to renew","we were unable to renew","final warning","action required"
  ]);

  const paymentFailure = has([
    "payment processing failed","payment declined","payment failed","unable to renew","renewal failed","processing failed",
    "payment method has expired","update payment","storage renewal failed"
  ]);

  const loginHarvest = has([
    "sign in","login","log in","verify your account","verify account","confirm your identity",
    "re-activate","reactivate","restore access","unlock","confirm your info","confirm & claim","confirm and claim",
    "update payment","update your payment","secure my data"
  ]);

  const prizeScam = has([
    "winner","gift card","free spins","casino","cashapp","claim","selected to receive","coupon code","payout","reward"
  ]);

  return { invoice, bankChange, urgency, accountThreat, paymentFailure, loginHarvest, prizeScam };
}

function maskIdentifier(s) {
  const v = String(s || "").trim();
  if (!v) return v;
  if (v.length <= 6) return v.replace(/.(?=.{2})/g, "•");
  const head = v.slice(0, 2);
  const tail = v.slice(-4);
  return `${head}${"•".repeat(Math.max(0, v.length - 6))}${tail}`;
}

function extractPaymentIdentifiers(text) {
  const t = String(text || "");
  const out = new Set();

  // IBAN-like
  for (const m of t.matchAll(/\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/g)) out.add(`IBAN: ${maskIdentifier(m[0])}`);

  // SWIFT/BIC (8 or 11)
  for (const m of t.matchAll(/\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?\b/g)) {
    const s = m[0];
    if (s.length === 8 || s.length === 11) out.add(`SWIFT: ${maskIdentifier(s)}`);
  }

  // IFSC (India)
  for (const m of t.matchAll(/\b[A-Z]{4}0[A-Z0-9]{6}\b/g)) out.add(`IFSC: ${maskIdentifier(m[0])}`);

  // UPI ID (India)
  for (const m of t.matchAll(/\b[a-z0-9._-]{2,}@[a-z0-9._-]{2,}\b/gi)) {
    const upi = m[0];
    // Filter obvious emails: if it contains '.' after @ it might be email; UPI usually no dot TLD.
    const at = upi.split("@")[1] || "";
    if (at.includes(".")) continue;
    out.add(`UPI: ${maskIdentifier(upi)}`);
  }

  // Long account-like numbers (basic)
  for (const m of t.matchAll(/\b\d{10,18}\b/g)) out.add(`Account: ${maskIdentifier(m[0])}`);

  return Array.from(out).slice(0, 10);
}

function buildBusinessEvidenceBundle(state) {
  const p = state?.aiPayload || {};
  const r = computeBusinessRisk(state);
  const lines = [];
  lines.push("AI Mail Genie — Business Protection Evidence");
  lines.push(`Subject: ${state?.subject || ""}`);
  lines.push(`From: ${state?.senderEmail || ""}`);
  lines.push(`Sender domain: ${state?.senderDomain || ""}`);
  lines.push(`Mailed-by: ${p.mailedBy || "—"}`);
  lines.push(`Signed-by: ${p.signedBy || "—"}`);
  lines.push(`Verified sender: ${p.gmailVerifiedSender ? "Yes" : "No/Unknown"}`);
  lines.push(`External links: ${Array.isArray(p.linkUrls) ? p.linkUrls.length : 0}`);
  lines.push(`Payment details changed (thread baseline): ${p.paymentChanged ? "Yes" : "No"}`);
  lines.push("");
  lines.push(`Identity risk: ${r.identityRisk}%`);
  lines.push(`Payment fraud risk: ${r.paymentRisk}%`);
  lines.push("");
  if (r.drivers.length) {
    lines.push("Why flagged:");
    for (const d of r.drivers.slice(0, 10)) lines.push(`- ${d}`);
    lines.push("");
  }
  if (r.identifiers.length) {
    lines.push("Detected payment identifiers (masked):");
    for (const id of r.identifiers) lines.push(`- ${id}`);
    lines.push("");
  }
  lines.push("Recommended next steps:");
  for (const s of r.nextSteps) lines.push(`- ${s}`);
  return lines.join("\n");
}


  function renderMessages(messages) {
    LAST_RENDERED_MESSAGES = Array.isArray(messages) ? messages : [];
    const p = ensurePanel();
    const body = p.querySelector("#amg_body");
    body.innerHTML = "";

    const mode = getAnalysisMode();

    // 1) Email signals always first
    if (currentState) {
      try {
        body.appendChild(buildPremiumOverviewCard(currentState));
      } catch (e) {
        LOG("Premium overview render failed:", e);
      }
    }

    // 2) Build message nodes first so we can place AI analysis second
    const nodes = [];
    let firstAiIdx = -1;

    for (const m of messages) {
      // Skeleton states
      const txt = (m && (m.text || m.content || m.message || m)) ? String(m.text || m.content || m.message || m) : "";
      const role = (m && (m.role || m.from)) ? String(m.role || m.from) : "";

      const isSkeleton = role === "system" && /analyzing|thinking/i.test(txt);
      const isUser = role === "user";

      if (isUser) {
        const div = el("div", "amg-user");
        div.textContent = txt;
        nodes.push({ kind: "user", node: div });
        continue;
      }

      if (isSkeleton) {
        const node = buildSkeletonCard(txt.trim().replace("…", ""));
        if (firstAiIdx === -1) firstAiIdx = nodes.length;
        nodes.push({ kind: "ai", node });
        continue;
      }

      // Assistant message as premium card with collapsibles + actions
      const node = buildAssistantPremiumCard(txt);
      if (firstAiIdx === -1) firstAiIdx = nodes.length;
      nodes.push({ kind: "ai", node });
    }

    // Place first AI/Skeleton node second (right after Email signals)
    if (firstAiIdx >= 0) {
      body.appendChild(nodes[firstAiIdx].node);
    }

    // 3) Sender controls next (both modes)
    if (currentState) {
      try {
        body.appendChild(buildSenderControlsCard(currentState));
      } catch (e) {
        LOG("Sender controls render failed:", e);
      }
    }

    // 4) Business mode: add protection section (local heuristics only)
    if (mode === "business" && currentState) {
      try {
        body.appendChild(buildBusinessProtectionCard(currentState));
      } catch (e) {
        LOG("Business protection render failed:", e);
      }
    }

    // 5) Append remaining message nodes in original order (excluding the one already placed)
    for (let i = 0; i < nodes.length; i++) {
      if (i === firstAiIdx) continue;
      body.appendChild(nodes[i].node);
    }

body.scrollTop = body.scrollHeight;
    applyPlanGatingUI();
  }

  function setMeta(text) {
    const p = ensurePanel();
    p.querySelector("#amg_meta").textContent = text || "";
  }

  async function rerunAnalysisForCurrentEmail() {
    const state = currentState;
    if (!state) return;

    // Clear stored history so we force a fresh initial analysis
    await saveChatHistory(state.chatKey, []);
    await openPanelForCurrentEmail({ forceRefresh: true });
  }

  async function openPanelForCurrentEmail({ forceRefresh }) {
    await refreshStatusFromBackground();

    const state = currentState;
    const p = ensurePanel();
    p.classList.add("open");

    applyPlanGatingUI();

    if (!state) {
      setMeta("No email selected");
      renderMessages([{ role: "assistant", content: "Open an email, then click Assistant." }]);
      return;
    }

    setMeta(`${state.senderEmail || ""} • ${state.subject || ""}`);

    const chatKey = state.chatKey;
    let history = forceRefresh ? [] : await loadChatHistory(chatKey);

    if (!history.length) {
      history = [{ role: "assistant", content: "Analyzing…" }];
      renderMessages(history);

      const resp = await sendAIChat({
        ...state.aiPayload,
        mode: PLAN_MODE,
        strictness: STRICTNESS,
        history: [],
        userMessage: null
      });

      if (!resp || !resp.ok) {
        history = [{ role: "assistant", content: `Error: ${resp?.error || "AI request failed"}` }];
        renderMessages(history);
        await saveChatHistory(chatKey, history);
        return;
      }

      const reply = resp.data?.reply || resp.data?.summary || JSON.stringify(resp.data || {}, null, 2);

      // If server indicates Free, flip UI back
      if (looksLikeUpgradeRequiredReply(reply)) {
        PLAN_MODE = "free";
        PLAN_TIER = "free";
        PLAN_EXPIRES_AT = null;
        await savePlan("free", STRICTNESS);
      }

      history = [{ role: "assistant", content: reply }];
      renderMessages(history);
      await saveChatHistory(chatKey, history);
      return;
    }

    renderMessages(history);
  }

  async function onSend() {
    if (PLAN_MODE !== "pro") {
      openUpgrade();
      return;
    }

    const p = ensurePanel();
    const input = p.querySelector("#amg_input");
    const text = normalizeText(input.value);
    if (!text) return;
    input.value = "";

    const state = currentState;
    if (!state) return;

    const chatKey = state.chatKey;
    let history = await loadChatHistory(chatKey);

    history.push({ role: "user", content: text });
    history.push({ role: "assistant", content: "Thinking…" });
    renderMessages(history);

    const resp = await sendAIChat({
      ...state.aiPayload,
      mode: PLAN_MODE,
      strictness: STRICTNESS,
      history: history
        .filter((m) => m.role === "user" || m.role === "assistant")
        .slice(-12)
        .map((m) => ({ role: m.role, content: m.content })),
      userMessage: text
    });

    history = history.filter((m) => !(m.role === "assistant" && m.content === "Thinking…"));

    if (!resp || !resp.ok) {
      history.push({ role: "assistant", content: `Error: ${resp?.error || "AI request failed"}` });
      renderMessages(history);
      await saveChatHistory(chatKey, history);
      return;
    }

    const reply = resp.data?.reply || JSON.stringify(resp.data || {}, null, 2);

    if (looksLikeUpgradeRequiredReply(reply)) {
      PLAN_MODE = "free";
      PLAN_TIER = "free";
      PLAN_EXPIRES_AT = null;
      await savePlan("free", STRICTNESS);
    }

    history.push({ role: "assistant", content: reply });
    renderMessages(history);
    await saveChatHistory(chatKey, history);
  }

  // -------------------------
  // Gmail email extraction
  // -------------------------
  function pickMainGmail() {
    return document.querySelector('div[role="main"]') || document.body;
  }

  function isGmailMessageOpen(main) {
    const root = main || document;
    // Common Gmail message body containers
    if (root.querySelector("div.a3s")) return true;
    if (root.querySelector("div.adn")) return true;
    // Fallback: if a message header exists
    if (root.querySelector('h2[data-thread-perm-id], h2.hP')) return true;
    return false;
  }

  function gmailThreadKey() {
    return (location.hash ? location.hash.slice(1) : location.pathname).slice(0, 240);
  }

  function gmailSubject(main) {
    const h2 = (main || document).querySelector("h2") || document.querySelector("h2");
    return normalizeText(h2?.textContent || "");
  }

  function gmailSenderEmail(main) {
    const el =
      (main || document).querySelector("span[email]") ||
      (main || document).querySelector("span.gD") ||
      document.querySelector("span[email]") ||
      document.querySelector("span.gD");
    return el?.getAttribute("email") || el?.getAttribute("title") || el?.textContent || "";
  }

  function gmailBodyEl(main) {
    return (main || document).querySelector("div.a3s") || (main || document);
  }

  function gmailVerifiedSender(main) {
    // Best-effort: detect Gmail "Verified sender" badge (blue check).
    // We look for visible elements in the message header area that include "Verified".
    try {
      const root = main || document;
      const els = Array.from(
        root.querySelectorAll('[aria-label*="Verified" i],[title*="Verified" i],[data-tooltip*="Verified" i]')
      ).slice(0, 30);
      for (const el of els) {
        const label = (el.getAttribute("aria-label") || el.getAttribute("title") || el.getAttribute("data-tooltip") || "").trim();
        if (!label) continue;
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        // Header zone heuristic (prevents matching random "verified" text in body)
        if (r.top < 0 || r.top > 420) continue;
        return { isVerified: true, label };
      }
    } catch {}
    return { isVerified: false, label: "" };
  }

  function gmailAuthHints(main) {
    const root = main || document;
    const text = normalizeText(root.innerText || "");
    const mailed = (text.match(/\bmailed-by\s+([a-z0-9.-]+\.[a-z]{2,})/i) || [])[1] || "";
    const signed = (text.match(/\bsigned-by\s+([a-z0-9.-]+\.[a-z]{2,})/i) || [])[1] || "";
    return { mailedBy: mailed.toLowerCase(), signedBy: signed.toLowerCase() };
  }

  // -------------------------
  // Outlook extraction (heuristics)
  // -------------------------
  function outlookFindMessageBodyFrame() {
    return (
      document.querySelector('iframe[title="Message body"]') ||
      document.querySelector('iframe[aria-label="Message body"]') ||
      null
    );
  }

  function outlookFindMessageBodyEl() {
    const frame = outlookFindMessageBodyFrame();
    if (frame && frame.contentDocument && frame.contentDocument.body) {
      return frame.contentDocument.body;
    }
    return (
      document.querySelector('div[role="document"]') ||
      document.querySelector('[aria-label="Message body"]') ||
      document.querySelector('[data-testid="message-body"]') ||
      document.querySelector('div[aria-label*="Reading pane" i]') ||
      null
    );
  }

  function isOutlookMessageOpen() {
    const body = outlookFindMessageBodyEl();
    if (!body) return false;
    const t = normalizeText(body.innerText || body.textContent || "");
    return t.length > 20;
  }

  function outlookThreadKey() {
    const href = location.href || "";
    const m = href.match(/\/id\/([^/?#]+)/i);
    if (m && m[1] && m[1].length > 10) return m[1].slice(0, 240);
    if (href.length > 15) return href.slice(0, 240);
    return "outlook-unknown";
  }

  function outlookSubject() {
    const candidates = ['[data-testid="message-subject"]', "h1", "h2", '[role="heading"]'];
    for (const sel of candidates) {
      const el = document.querySelector(sel);
      const txt = normalizeText(el?.textContent || "");
      if (txt && txt.length > 2 && txt.length < 180) return txt;
    }
    return "";
  }

  function outlookSenderEmail() {
    const findEmail = (txt) => {
      const m = (txt || "").match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
      return m ? m[0] : "";
    };

    const fromNode =
      document.querySelector('[data-testid="message-from"]') ||
      document.querySelector('[aria-label^="From" i]') ||
      document.querySelector('[aria-label*="From:" i]') ||
      null;

    let email = "";
    if (fromNode) email = findEmail(normalizeText(fromNode.innerText || fromNode.textContent || ""));

    if (!email) {
      const withTitle = Array.from(document.querySelectorAll('[title*="@"]')).slice(0, 40);
      for (const el of withTitle) {
        const t = el.getAttribute("title") || "";
        const e = findEmail(t);
        if (e) return e;
      }
    }

    return email || "";
  }

  function outlookAuthHints() {
    return { mailedBy: "", signedBy: "" };
  }

  // -------------------------
  // Payment hash (thread-local) for paymentChanged signal
  // -------------------------
  function extractPaymentBlob(text) {
    const t = text || "";
    const iban = t.match(/\b([A-Z]{2}\d{2}[A-Z0-9]{10,30})\b/g) || [];
    const routing = t.match(/\b(routing number|aba)\b[\s:.-]*\b(\d{9})\b/gi) || [];
    const acct = t.match(/\b(account number)\b[\s:.-]*\b(\d{6,17})\b/gi) || [];
    const bankish = [];
    for (const line of t.split("\n")) {
      const low = line.toLowerCase();
      if (low.includes("beneficiary") || low.includes("bank") || low.includes("swift") || low.includes("iban")) {
        const digits = line.match(/\d{8,}/g) || [];
        bankish.push(...digits);
      }
    }
    return normalizeText([...iban, ...routing, ...acct, ...bankish].join(" | "));
  }

  // -------------------------
  // Build email state
  // -------------------------
  async function buildGmailState() {
    const main = pickMainGmail();
    if (!main) return null;

    const senderEmail = gmailSenderEmail(main);
    const senderDomainRaw = getDomainFromEmail(senderEmail);
    const senderDomain = getBaseDomain(senderDomainRaw) || senderDomainRaw;

    const subject = gmailSubject(main);
    const bodyEl = gmailBodyEl(main);
    const bodyText = extractPlainText(bodyEl);

    const linkUrls = extractLinks(bodyEl);
    const linkDomainsRaw = Array.from(new Set(linkUrls.map(getDomainFromUrl).filter(Boolean)));
    const linkDomains = Array.from(new Set(linkDomainsRaw.map(getBaseDomain).filter(Boolean)));
    const externalLinkUrls = filterExternalLinkUrls(linkUrls, senderDomain);

    const auth = gmailAuthHints(main);
    const verified = gmailVerifiedSender(main);

    let paymentChanged = false;
    const blob = extractPaymentBlob(bodyText);

    if (blob) {
      const paymentHash = await sha256Hex(blob);
      const ts = await getThreadState();
      const key = `gmail:${gmailThreadKey()}:${senderDomain || "unknown"}`;
      if (ts[key]?.lastPaymentHash && ts[key].lastPaymentHash !== paymentHash) paymentChanged = true;
      ts[key] = { lastPaymentHash: paymentHash, lastSeenAt: Date.now() };
      await setThreadState(ts);
    }

    const tKey = gmailThreadKey();
    return {
      senderEmail,
      senderDomain,
      subject,
      bodyText,
      linkDomains,
      threadKey: tKey,
      chatKey: `gmail:${tKey}`,
      aiPayload: {
        provider: "gmail",
        threadKey: tKey,
        senderEmail,
        senderDomain,

        // extra context (backend may ignore extras, but safe)
        gmailVerifiedSender: !!verified.isVerified,
        gmailVerifiedLabel: verified.label || "",
        rawLinkDomains: linkDomainsRaw.slice(0, 20),

        subject,
        linkDomains,
        linkUrls: externalLinkUrls.slice(0, 12),

        mailedBy: auth.mailedBy,
        signedBy: auth.signedBy,

        paymentChanged,
        paymentIntent: false,

        redactedSnippet: redactForAI(bodyText)
      }
    };
  }
  async function buildOutlookState() {
    const senderEmail = outlookSenderEmail();
    const senderDomainRaw = getDomainFromEmail(senderEmail);
    const senderDomain = getBaseDomain(senderDomainRaw) || senderDomainRaw;

    const subject = outlookSubject();
    const bodyEl = outlookFindMessageBodyEl();
    const bodyText = extractPlainText(bodyEl);

    const linkUrls = extractLinks(bodyEl);
    const linkDomainsRaw = Array.from(new Set(linkUrls.map(getDomainFromUrl).filter(Boolean)));
    const linkDomains = Array.from(new Set(linkDomainsRaw.map(getBaseDomain).filter(Boolean)));
    const externalLinkUrls = filterExternalLinkUrls(linkUrls, senderDomain);

    const auth = outlookAuthHints();

    // Outlook verified badge detection not implemented (safe default)
    const verified = { isVerified: false, label: "" };

    let paymentChanged = false;
    const blob = extractPaymentBlob(bodyText);

    if (blob) {
      const paymentHash = await sha256Hex(blob);
      const ts = await getThreadState();
      const tKey = outlookThreadKey();
      const key = `outlook:${tKey}:${senderDomain || "unknown"}`;
      if (ts[key]?.lastPaymentHash && ts[key].lastPaymentHash !== paymentHash) paymentChanged = true;
      ts[key] = { lastPaymentHash: paymentHash, lastSeenAt: Date.now() };
      await setThreadState(ts);
    }

    const tKey = outlookThreadKey();
    return {
      senderEmail,
      senderDomain,
      subject,
      bodyText,
      linkDomains,
      threadKey: tKey,
      chatKey: `outlook:${tKey}`,
      aiPayload: {
        provider: "outlook",
        threadKey: tKey,
        senderEmail,
        senderDomain,

        // extra context (backend may ignore extras, but safe)
        gmailVerifiedSender: !!verified.isVerified,
        gmailVerifiedLabel: verified.label || "",

        subject,
        linkDomains,
        linkUrls: externalLinkUrls.slice(0, 12),

        mailedBy: auth.mailedBy,
        signedBy: auth.signedBy,

        paymentChanged,
        paymentIntent: false,

        redactedSnippet: redactForAI(bodyText)
      }
    };
  }

  // -------------------------
  // Snapshot loop
  // -------------------------
  let ticking = false;
  let currentState = null;
  let lastDigest = "";
  let lastThreadKey = "";

  async function computeState() {
    ensureStyles();

    const prov = providerName();
    if (prov !== "gmail" && prov !== "outlook") return null;

    // When NOT in a message view, show toolbar icon and remove banner/panel
    if (prov === "gmail") {
      const main = pickMainGmail();
      if (!isGmailMessageOpen(main)) {
        injectTopIndicatorByProvider();
        removeUI();
        currentState = null;
        lastDigest = "";
        lastThreadKey = "";
        return null;
      }

      // In message view: remove toolbar icon
      document.getElementById(TOP_BADGE_ID)?.remove();

      const next = await buildGmailState();
      if (!next) return null;

      const digest = normalizeText(
        [prov, next.threadKey, next.senderEmail, next.subject, next.aiPayload.redactedSnippet.slice(0, 200)].join("|")
      );
      if (digest === lastDigest) return currentState;
      lastDigest = digest;

      if (lastThreadKey && next.threadKey !== lastThreadKey) {
        // email changed while panel may be open
        const p = document.getElementById(PANEL_ID);
        if (p && p.classList.contains("open")) {
          setMeta("New email selected • Click Assistant to analyze");
          renderMessages([{ role: "assistant", content: "New email selected. Click Assistant to analyze this email." }]);
        }
      }
      lastThreadKey = next.threadKey;

      currentState = next;

      upsertBanner();
      applySettingsToUI();
      return next;
    }

    if (prov === "outlook") {
      if (!isOutlookMessageOpen()) {
        injectTopIndicatorByProvider();
        removeUI();
        currentState = null;
        lastDigest = "";
        lastThreadKey = "";
        return null;
      }

      document.getElementById(TOP_BADGE_ID)?.remove();

      const next = await buildOutlookState();
      if (!next) return null;

      const digest = normalizeText(
        [prov, next.threadKey, next.senderEmail, next.subject, next.aiPayload.redactedSnippet.slice(0, 200)].join("|")
      );
      if (digest === lastDigest) return currentState;
      lastDigest = digest;

      if (lastThreadKey && next.threadKey !== lastThreadKey) {
        const p = document.getElementById(PANEL_ID);
        if (p && p.classList.contains("open")) {
          setMeta("New email selected • Click Assistant to analyze");
          renderMessages([{ role: "assistant", content: "New email selected. Click Assistant to analyze this email." }]);
        }
      }
      lastThreadKey = next.threadKey;

      currentState = next;

      upsertBanner();
      applySettingsToUI();
      return next;
    }

    return null;
  }

  function schedule() {
    if (ticking) return;
    ticking = true;
    setTimeout(async () => {
      ticking = false;
      try {
        await computeState();
      } catch (e) {
        LOG("Error:", e);
      }
    }, 350);
  }

  async function init() {
    const prov = providerName();
    if (prov !== "gmail" && prov !== "outlook") return;

    SETTINGS = await loadSettings();
    await loadSenderLists();

    await refreshStatusFromBackground();

    // If background doesn't have plan yet, fall back to local plan
    if (!PLAN_MODE || PLAN_MODE === "free") {
      const plan = await loadPlan();
      applyPlanToRuntime(plan);
    }

    ensureStyles();
    applySettingsToUI();
    injectTopIndicatorByProvider();

    const obs = new MutationObserver(schedule);
    obs.observe(document.documentElement, { childList: true, subtree: true });

    schedule();
  }

  init();
})();
